#pragma once

#include <cstring>
#include <deque>
namespace bellmanford {
using namespace std;
#define fastcall __attribute__((optimize("-O3")))
#define IL __inline__ __attribute__((always_inline))
template <typename T, int maxn, int R = 200, int dist = 10>
class BellmanFord {
public:
    BellmanFord(void) { init(); }
    fastcall IL void init(void) {
        memset(G, 0, sizeof(G));
        memset(head, 0, sizeof(head));
        cnt = 0;
        return;
    }
    fastcall IL void AddEdge(const int &u, const int &v, const T &val) {
        G[++cnt].to = v;
        G[cnt].nxt = head[u];
        G[cnt].val = val;
        head[u] = cnt;
        return;
    }
    T d[maxn];
    int p[maxn];
    fastcall IL void bellmanford(const int &s = 1) {
        deque<int> Q;
        memset(d, 0x3f, sizeof(d));
        memset(inq, false, sizeof(inq));
        d[s] = 0, inq[s] = true;
        memset(c, 0, sizeof(c));
        memset(p, 0, sizeof(p));
        Q.push_front(s);
        while (!Q.empty()) {
            int u = Q.front();
            Q.pop_front();
            inq[u] = false;
            for (int i = head[u]; i; i = G[i].nxt)
                if (d[G[i].to] > d[u] + G[i].val) {
                    d[G[i].to] = d[u] + G[i].val;
                    p[G[i].to] = i;
                    if (!inq[G[i].to]) {
                        inq[G[i].to] = true;
                        if (c[G[i].to] && c[G[i].to] < R) {
                            Q.push_front(G[i].to);
                            c[G[i].to]++;
                        } else {
                            if (!Q.size())
                                Q.push_back(G[i].to);
                            else if (d[*(Q.begin())] >= d[G[i].to] - dist)
                                Q.push_front(G[i].to);
                            else
                                Q.push_back(G[i].to);
                            if (!c[G[i].to])
                                c[G[i].to] = 1;
                        }
                    }
                }
        }
        return;
    }
    struct edge {
        int to, nxt;
        T val;
    };
    edge G[maxn];
    int head[maxn], cnt;

private:
    bool inq[maxn];
    int c[maxn];
};
}  // namespace bellmanford
using namespace bellmanford;
