#pragma once

#include <algorithm>
#include <cstring>
namespace kruskalreconstruction {
using namespace std;
template <typename T, int maxn>
class KruskalReconstruction {
public:
    inline void init(const int &n) {
        this->n = n;
        tcnt = 0;
        return;
    }
    inline void AddEdge(const int &u, const int &v, const T &val) {
        tG[++tcnt].from = u;
        tG[tcnt].to = v;
        tG[tcnt].val = val;
        return;
    }
    inline T solve(void) {
        memset(used, false, sizeof(used));
        memset(val, 0, sizeof(val));
        T ans = 0;
        int num = 0;
        sort(tG + 1, tG + tcnt + 1);
        s.init(n);
        for (int i = 1; i <= tcnt; i++) {
            if (!s.Find(tG[i].from, tG[i].to)) {
                used[i] = true;
                ans += tG[i].val;
                s.Union(tG[i].from, tG[i].to);
                val[n + (++num)] = tG[i].val;
                addedge(tG[i].from, n + num);
                addedge(tG[i].to, n + num);
                addedge(n + num, tG[i].from);
                addedge(n + num, tG[i].to);
                if (num == n - 1)
                    break;
            }
        }
        return ans;
    }
    bool used[maxn];
    struct edge {
        int to, nxt;
    };
    int head[maxn << 1], cnt;
    T val[maxn << 1];
    edge G[maxn << 2];

private:
    int n;
    struct tedge {
        int from, to;
        T val;
        inline const bool operator<(const tedge &p) const { return val < p.val; }
    };
    int tcnt;
    tedge tG[maxn];
    inline void addedge(const int &u, const int &v) {
        G[++cnt].to = v;
        G[cnt].nxt = head[u];
        head[u] = cnt;
        return;
    }
    class UnionFindSet {
    public:
        inline void init(const int &n) {
            memset(fa, 0, sizeof(fa));
            for (int i = 1; i <= n; i++) fa[i] = i;
            memset(rank, 0, sizeof(rank));
            return;
        }
        inline void Union(const int &u, const int &v) {
            int x = find(u), y = find(v);
            if (rank[x] < rank[y])
                fa[x] = y;
            else {
                fa[y] = x;
                if (rank[x] == rank[y])
                    rank[x]++;
            }
            return;
        }
        inline bool Find(const int &u, const int &v) { return this->find(u) == this->find(v); }
        int fa[maxn];

    private:
        int find(const int &u) { return fa[u] == u ? u : fa[u] = find(fa[u]); }
        int rank[maxn];
    };
    UnionFindSet s;
};
}  // namespace kruskalreconstruction
using namespace kruskalreconstruction;
