#pragma once

#include <cstring>
#include <queue>
namespace prim {
using namespace std;
#define fastcall __attribute__((optimize("-O3")))
#define IL __inline__ __attribute__((always_inline))
template <typename T, int maxn>
class Prim {
public:
    fastcall IL void init(const int &n) {
        this->n = n;
        cnt = 0;
        return;
    }
    fastcall IL void AddEdge(const int &u, const int &v, const T &val) {
        G[++cnt].from = u;
        G[cnt].to = v;
        G[cnt].val = val;
        return;
    }
    T dist[maxn];
    fastcall IL T Prim(void) {
        memset(used, false, sizeof(used));
        T ans = 0;
        int num = 0;
        memset(dist,0,sizeof(dist));
        dist[1]=0;
        
        return ans;
    }
    bool used[maxn];
    struct edge {
        int from, to;
        T val;
        inline const bool operator<(const edge &p) const { return val < p.val; }
    };
    int cnt;
    edge G[maxn];

private:
    int n;
};
}  // namespace Prim
using namespace prim;
