#pragma once

#include <algorithm>
#include <vector>
namespace numbertheoretictransform {
using namespace std;
#define fastcall __attribute__((optimize("-O3")))
#define IL __inline__ __attribute__((always_inline))
const int mod = 998244353, gen = 3;
fastcall IL int pow(int b, int e) {
    int ret = 1;
    while (e) {
        if (e & 1)
            ret = ((long long)ret * b) % mod;
        e >>= 1;
        b = ((long long)b * b) % mod;
    }
    return ret;
}
fastcall IL void getvec(vector<int> &r, const int &n) {
    r.clear();
    r.push_back(0);
    for (int i = 1; i < n; i++) r.push_back((r[i >> 1] >> 1) | ((i & 1) ? n >> 1 : 0));
    return;
}
fastcall IL void NTT(vector<int> &v, const int &lim, const vector<int> &r, const bool &opt = false) {
    for (int i = 0; i < lim; i++)
        if (r[i] < i)
            v[i] ^= v[r[i]] ^= v[i] ^= v[r[i]];
    int k, g, tmpg, t;
    for (int m = 2; m <= lim; m <<= 1) {
        k = m >> 1;
        g = pow(gen, (mod - 1) / m);
        for (int i = 0; i < lim; i += m) {
            tmpg = 1;
            for (int j = 0; j < k; j++) {
                t = ((long long)v[i + j + k] * tmpg) % mod;
                v[i + j + k] = ((long long)v[i + j] - t + mod) % mod;
                v[i + j] = ((long long)v[i + j] + t) % mod;
                tmpg = ((long long)tmpg * g) % mod;
            }
        }
    }
    if (opt) {
        reverse(v.begin() + 1, v.end());
        int inv = pow(lim, mod - 2);
        for (int i = 0; i < lim; i++) v[i] = ((long long)v[i] * inv) % mod;
    }
    return;
}
}  // namespace numbertheoretictransform
using namespace numbertheoretictransform;
