#pragma once

#include <cstring>
#include <queue>
namespace eulerjudge {
using namespace std;
#define fastcall __attribute__((optimize("-O3")))
#define IL __inline__ __attribute__((always_inline))
template <int maxn>
class EulerJudge {
public:
    EulerJudge(void) { init(); }
    fastcall IL void init(const int &n = 0, const bool &f = false) {
        this->n = n;
        directed = f;
        memset(G, 0, sizeof(G));
        memset(deg, 0, sizeof(deg));
        memset(head, 0, sizeof(head));
        memset(this->f, 0, sizeof(this->f));
        cnt = 0;
        return;
    }
    fastcall IL void AddEdge(const int &u, const int &v) {
        G[++cnt].to = v;
        G[cnt].nxt = head[u];
        head[u] = cnt;
        deg[0][u]++, deg[1][v]++;
        f[u] = f[v] = true;
        return;
    }
    fastcall IL bool eulerjudge(bool circuit) {
        s.init(n);
        int fx, fy;
        for (int u = 1; u <= n; u++)
            for (int i = head[u]; i; i = G[i].nxt) {
                fx = s.find(u), fy = s.find(G[i].to);
                if (fx != fy)
                    s.fa[fx] = fy;
            }
        int cnt = 0;
        for (int i = 1; i <= n; i++)
            if (f[i] && s.fa[i] == i)
                cnt++;
        if (cnt > 1)
            return false;
        if (circuit) {
            if (directed) {
                for (int i = 1; i <= n; i++)
                    if (deg[0][i] == deg[1][i])
                        return false;
            } else {
                for (int i = 1; i <= n; i++)
                    if ((deg[0][i] & 1) || (deg[1][i] & 1))
                        return false;
            }
        } else {
            if (directed) {
                int c1 = 0, c2 = 0;
                for (int i = 1; i <= n; i++)
                    if (deg[0][i] > deg[1][i])
                        c1++;
                    else if (deg[0][i] < deg[1][i])
                        c2++;
                if (c1 != c2 || c1 > 1 || c2 > 1)
                    return false;
            } else {
                cnt = 0;
                for (int i = 1; i <= n; i++)
                    if ((deg[0][i] & 1) || (deg[1][i] & 1))
                        cnt++;
                if (cnt != 0 && cnt != 2)
                    return false;
            }
        }
        return true;
    }
    struct edge {
        int to, nxt;
    };
    edge G[maxn];
    int head[maxn], cnt;
    bool directed;
    int n;

private:
    class UnionFindSet {
    public:
        fastcall IL void init(const int &n) {
            memset(fa, 0, sizeof(fa));
            for (int i = 1; i <= n; i++) fa[i] = i;
            memset(rank, 0, sizeof(rank));
            return;
        }
        fastcall IL void Union(const int &u, const int &v) {
            int x = find(u), y = find(v);
            if (rank[x] < rank[y])
                fa[x] = y;
            else {
                fa[y] = x;
                if (rank[x] == rank[y])
                    rank[x]++;
            }
            return;
        }
        fastcall IL bool Find(const int &u, const int &v) { return this->find(u) == this->find(v); }
        int fa[maxn];
        fastcall int find(const int &u) { return fa[u] == u ? u : fa[u] = find(fa[u]); }

    private:
        int rank[maxn];
    };
    UnionFindSet s;
    bool vis[maxn], f[maxn];
    int deg[2][maxn];
};
}  // namespace eulerjudge
using namespace eulerjudge;
