#pragma once

namespace power {
using namespace std;
#define fastcall __attribute__((optimize("-O3")))
#define IL __inline__ __attribute__((always_inline))
template <typename T>
fastcall IL T Power(T b, T e, const T &mod) {
    T ret = 1;
    while (e) {
        if (e & 1)
            ret = (ret * b) % mod;
        e >>= 1;
        b = (b * b) % mod;
    }
    return ret;
}
}  // namespace power
using namespace power;
