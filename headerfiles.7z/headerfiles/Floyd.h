#pragma once

#include <cstring>
namespace floyd {
using namespace std;
#define fastcall __attribute__((optimize("-O3")))
#define IL __inline__ __attribute__((always_inline))
template <typename T, int maxn>
class Floyd {
public:
    fastcall IL void init(const int &n) {
        memset(d, 0x3f, sizeof(d));
        this->n = n;
        cnt = 0;
        return;
    }
    fastcall IL void AddEdge(int from, int to, int dist) {
        d[from][to] = dist;
        return;
    }
    fastcall IL void floyd(void) {
        for (int i = 1; i <= n; i++) d[i][i] = 0;
        for (int k = 1; k <= n; k++)
            for (int i = 1; i <= n; i++)
                if (d[i][k] != d[0][0])
                    for (int j = 1; j <= n; j++)
                        if (d[k][j] != d[0][0] && d[i][j] > d[i][k] + d[k][j])
                            d[i][j] = d[i][k] + d[k][j];
        return;
    }
    T d[maxn][maxn];

private:
    int n;
};
}  // namespace floyd
using namespace floyd;
