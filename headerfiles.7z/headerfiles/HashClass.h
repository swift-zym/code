#pragma once

#include <vector>
#include <string>
namespace hashclass {
using namespace std;
#define fastcall __attribute__((optimize("-O3")))
#define IL __inline__ __attribute__((always_inline))
template <unsigned long long mod, unsigned long long base = 19260817>
class HashClass {
public:
    fastcall IL void init(const string &str) {
        h.clear();
        p.clear();
        h.push_back((unsigned long long)str[0]);
        p.push_back(1);
        for (int i = 1; i < str.length(); i++) {
            h.push_back(((h[i - 1] * base) % mod + str[i]) % mod);
            p.push_back((p[i - 1] * base) % mod);
        }
        return;
    }
    fastcall IL unsigned long long get_hash(const int &l, const int &r) const {
        if (l == 0)
            return h[r];
        return (h[r] - (h[l - 1] * p[r - l + 1]) % mod + mod) % mod;
    }

private:
    vector<unsigned long long> h, p;
};
}  // namespace hashclass
using namespace hashclass;
