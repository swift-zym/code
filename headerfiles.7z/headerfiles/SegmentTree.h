#pragma once

#include <vector>
namespace segmenttree {
using namespace std;
#define fastcall __attribute__((optimize("-O3")))
#define IL __inline__ __attribute__((always_inline))
template <typename T, int maxn>
class SegmentTree {
public:
    SegmentTree() : cnt(0) { root = &pool[cnt]; }
    fastcall IL void build(const vector<T> &v) {
        Build(root, 0, v.size() - 1, v);
        return;
    }
    fastcall IL void modify(const int &l, const int &r, const int &val) {
        Modify(root, l, r, val);
        return;
    }
    fastcall IL T query(const int &l, const int &r) { return Query(root, l, r); }

private:
    struct node {
        int left, right;
        T val, lazy;
        node *son[2];
    };
    node pool[maxn << 2], *root;
    int cnt;
    fastcall void Build(node *root, const int &l, const int &r, const vector<T> &v) {
        root->left = l, root->right = r;
        root->val = root->lazy = 0;
        if (l == r) {
            root->son[0] = root->son[1] = nullptr;
            root->val = v[l];
            return;
        }
        int mid = (l + r) >> 1;
        root->son[0] = &pool[++cnt];
        root->son[1] = &pool[++cnt];
        Build(root->son[0], l, mid, v);
        Build(root->son[1], mid + 1, r, v);
        root->val = root->son[0]->val + root->son[1]->val;
        return;
    }
    fastcall void Modify(node *root, const int &l, const int &r, const T &val) {
        if (root->left == l && root->right == r) {
            root->lazy += val;
            return;
        }
        push_down(root);
        if (root->son[0]->right >= r)
            Modify(root->son[0], l, r, val);
        else if (root->son[1]->left <= l)
            Modify(root->son[1], l, r, val);
        else {
            Modify(root->son[0], l, root->son[0]->right, val);
            Modify(root->son[1], root->son[1]->left, r, val);
        }
        push_down(root->son[0]);
        push_down(root->son[1]);
        push_up(root);
        return;
    }
    fastcall T Query(node *root, const int &l, const int &r) {
        push_down(root);
        if (root->left == l && root->right == r)
            return root->val;
        if (root->son[0]->right >= r)
            return Query(root->son[0], l, r);
        else if (root->son[1]->left <= l)
            return Query(root->son[1], l, r);
        return Query(root->son[0], l, root->son[0]->right) + Query(root->son[1], root->son[1]->left, r);
    }
    fastcall IL void push_up(node *p) {
        p->val = p->son[0]->val + p->son[1]->val;
        return;
    }
    fastcall IL void push_down(node *p) {
        if (!p->lazy)
            return;
        p->val += (p->right - p->left + 1) * p->lazy;
        if (p->son[0] != nullptr)
            p->son[0]->lazy += p->lazy;
        if (p->son[1] != nullptr)
            p->son[1]->lazy += p->lazy;
        p->lazy = 0;
        return;
    }
};
}  // namespace segmenttree
using namespace segmenttree;
