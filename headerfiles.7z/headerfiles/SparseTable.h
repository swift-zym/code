#pragma once

#include <algorithm>
#include <cstring>
#include <vector>
#include <cmath>
namespace sparsetable {
using namespace std;
#define fastcall __attribute__((optimize("-O3")))
#define IL __inline__ __attribute__((always_inline))
template <typename T, int maxn>
class SparseTable {
public:
    SparseTable(void) {
        lg[0] = -1;
        for (int i = 1; i < maxn; i++) lg[i] = lg[i >> 1] + 1;
        memset(d, 0, sizeof(d));
    }
    void preprocess(const vector<T> &A, const bool &flag = true) {
        this->flag = flag;
        n = A.size();
        for (int i = 0; i < n; i++) d[i][0] = A[i];
        for (int i = 1; (1 << i) <= n; i++)
            for (int j = 0; j + (1 << i) <= n; j++) d[j][i] = get(d[j][i - 1], d[j + (1 << (i - 1))][i - 1]);
        return;
    }
    T solve(int l, int r) {
        int k = lg[r - l + 1];
        return get(d[l][k], d[r - (1 << k) + 1][k]);
    }

private:
    T d[maxn][(int)log2(maxn) + 1];
    int lg[maxn];
    bool flag;
    int n;
    T get(T a, T b) {
        if (flag)
            return min(a, b);
        return max(a, b);
    }
};
}  // namespace sparsetable
using namespace sparsetable;
