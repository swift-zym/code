#pragma once

#include <cstring>
#include <queue>
namespace hlpp {
using namespace std;
template <typename T, int maxn>
class HLPP {
public:
    HLPP(void) { init(); }
    inline void init(void) {
        memset(G, 0, sizeof(G));
        memset(head, 0, sizeof(head));
        cnt = 1;
        return;
    }
    inline void AddEdge(const int &u, const int &v, const T &val) {
        addedge(u, v, val);
        addedge(v, u, 0);
        return;
    }
    inline T hlpp(const int &n, const int &s, const int &t) {
        static int h[maxn];
        memset(h, 0x3f, sizeof(h));
        static queue<int> Q;
        Q.push(t);
        h[t] = 0;
        int u;
        while (!Q.empty()) {
            u = Q.front();
            Q.pop();
            for (int i = head[u]; i; i = G[i].nxt)
                if (G[i ^ 1].val && h[G[i].to] > h[u] + 1)
                    h[G[i].to] = h[u] + 1, Q.push(G[i].to);
        }
        if (h[s] == h[0])
            return 0;
        h[s] = n;
        static T flow[maxn];
        static int gap[maxn];
        memset(flow, 0, sizeof(flow));
        memset(gap, 0, sizeof(gap));
        for (int i = 1; i <= n; i++)
            if (h[i] != h[0])
                gap[h[i]]++;
        static bool vis[maxn];
        memset(vis, 0, sizeof(vis));
        struct cmp {
            inline bool operator()(const int &a, const int &b) const { return h[a] < h[b]; }
        };
        static priority_queue<int, vector<int>, cmp> PQ;
        for (int i = head[s]; i; i = G[i].nxt)
            if (G[i].val) {
                flow[s] -= G[i].val, flow[G[i].to] += G[i].val;
                G[i ^ 1].val += G[i].val, G[i].val = 0;
                if (G[i].to != s && G[i].to != t && !vis[G[i].to])
                    PQ.push(G[i].to), vis[G[i].to] = true;
            }
        T v;
        bool flag;
        while (!PQ.empty()) {
            u = PQ.top();
            PQ.pop();
            vis[u] = false;
            while (true) {
                flag = false;
                if (!flow[u])
                    break;
                for (int i = head[u]; i; i = G[i].nxt) {
                    if (!G[i].val || h[u] != h[G[i].to] + 1)
                        continue;
                    v = min(G[i].val, flow[u]);
                    flow[u] -= v, flow[G[i].to] += v;
                    G[i].val -= v, G[i ^ 1].val += v;
                    if (G[i].to != s && G[i].to != t && !vis[G[i].to])
                        PQ.push(G[i].to), vis[G[i].to] = true;
                    if (!flow[u]) {
                        flag = true;
                        break;
                    }
                }
                if (flag)
                    break;
                if (!(--gap[h[u]]))
                    for (int i = 1; i <= n; i++)
                        if (i != s && i != t && h[i] > h[u] && h[i] <= n)
                            h[i] = n + 1;
                h[u] = h[0];
                for (int i = head[u]; i; i = G[i].nxt)
                    if (G[i].val && h[G[i].to] < h[u])
                        h[u] = h[G[i].to];
                gap[++h[u]]++;
            }
        }
        return flow[t];
    }

private:
    struct edge {
        int to, nxt;
        T val;
    };
    edge G[maxn << 1];
    int head[maxn], cnt;
    inline void addedge(const int &u, const int &v, const T &val) {
        G[++cnt].to = v;
        G[cnt].nxt = head[u];
        G[cnt].val = val;
        head[u] = cnt;
        return;
    }
};
}  // namespace hlpp
using namespace hlpp;
