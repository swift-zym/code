#pragma once

#include <cstring>
#include <vector>
#include <queue>
namespace ahocorasickautomata {
using namespace std;
#define fastcall __attribute__((optimize("-O3")))
#define IL __inline__ __attribute__((always_inline))
template <int maxn, int sigmasize>
class AhoCorasickAutomata {
public:
    AhoCorasickAutomata() { clear(); }
    fastcall IL void clear(void) {
        cnt = 1;
        memset(ch[0], 0, sizeof(ch[0]));
        memset(fail, 0, sizeof(fail));
        memset(val, 0, sizeof(val));
        return;
    }
    fastcall IL bool insert(const vector<int> &v, const int &num = 1) {
        int len = v.size(), u = 0;
        bool f = false;
        for (int i = 0; i < len; i++) {
            if (!ch[u][v[i]]) {
                memset(ch[cnt], 0, sizeof(ch[cnt]));
                val[cnt] = 0;
                ch[u][v[i]] = cnt++;
            } else if (i + 1 == len)
                f = true;
            u = ch[u][v[i]];
            if (val[u])
                f = true;
        }
        val[u] += num;
        return f;
    }
    fastcall IL void build(void) {
        queue<int> Q;
        for (int i = 0; i < sigmasize; i++)
            if (ch[0][i])
                Q.push(ch[0][i]);
        int u;
        while (!Q.empty()) {
            u = Q.front();
            Q.pop();
            for (int i = 0; i < sigmasize; i++)
                if (ch[u][i]) {
                    fail[ch[u][i]] = ch[fail[u]][i];
                    Q.push(ch[u][i]);
                } else
                    ch[u][i] = ch[fail[u]][i];
        }
        return;
    }
    fastcall IL int query(const vector<int> &v) const {
        memset(vis, 0, sizeof(vis));
        int len = v.size();
        int u = 0, ret = 0;
        for (int i = 0; i < len; i++) ret += count(u = ch[u][v[i]]);
        return ret;
    }

private:
    mutable bool vis[maxn];
    fastcall IL int count(int u) const {
        int ret = 0;
        while (u && !vis[u]) {
            ret += val[u];
            vis[u] = true;
            u = fail[u];
        }
        return ret;
    }
    int ch[maxn][sigmasize];
    int val[maxn], cnt;
    int fail[maxn];
};
}  // namespace ahocorasickautomata
using namespace ahocorasickautomata;
