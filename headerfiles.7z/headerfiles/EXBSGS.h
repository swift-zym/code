#pragma once

#include <cmath>
#include <unordered_map>
namespace exbsgs {
using namespace std;
#define fastcall __attribute__((optimize("-O3")))
#define IL __inline__ __attribute__((always_inline))
template <typename T>
fastcall IL T multyply(T x, T y, T mod) {
    x %= mod, y %= mod;
    return ((x * y - (T)(((long double)x * y + 0.5) / mod) * mod) % mod + mod) % mod;
}
template <typename T>
fastcall IL T EXBSGS(const T &a, T b, T p) {
    T d = 1, v, cnt = 0, ta, tp;
    while (true) {
        ta = a, tp = p;
        while (ta ^= tp ^= ta ^= tp %= ta) continue;
        v = tp;
        if (v == 1)
            break;
        if (b % v)
            return -1;
        b /= v, p /= v, cnt++;
        d = multyply(d, a / v, p);
        if (b == d)
            return cnt;
    }
    unordered_map<T, int> M;
    M.clear();
    M[b] = 0;
    T t = b, sqrtp = ceil(sqrt(p)), m = 1;
    for (int i = 1; i <= sqrtp; i++) t = multyply(t, a, p), M[t] = i;
    t = d, ta = a;
    T e = sqrtp;
    while (e) {
        if (e & 1)
            m = (m * ta) % p;
        e >>= 1, ta = (ta * ta) % p;
    }
    for (int i = 1; i <= sqrtp; i++) {
        t = multyply(t, m, p);
        if (M.count(t))
            return ((i * sqrtp - M[t] + cnt) % p + p) % p;
    }
    return -1;
}
}  // namespace exbsgs
using namespace exbsgs;
