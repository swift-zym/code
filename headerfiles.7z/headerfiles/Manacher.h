#pragma once

#include <vector>
#include <string>
namespace manacher {
using namespace std;
#define fastcall __attribute__((optimize("-O3")))
#define IL __inline__ __attribute__((always_inline))
vector<int> tmp;
fastcall IL int Manacher(const string &str, vector<int> &p = tmp) {
    string a;
    int n = str.length();
    a.resize((n << 1) + 1);
    a[0] = '#';
    for (int i = 0; i < n; i++) {
        a[(i << 1) + 1] = str[i];
        a[(i << 1) + 2] = '#';
    }
    n = a.length();
    int ret = 0, mid, r = 0;
    for (int i = 0; i < n; i++) {
        if (i < r)
            p.push_back(min(p[(mid << 1) - i], p[mid] + mid - i));
        else
            p.push_back(1);
        while (i + p[i] < n && i - p[i] >= 0 && a[i + p[i]] == a[i - p[i]]) p[i]++;
        if (p[i] > ret)
            ret = p[i];
        if (i + p[i] > r) {
            r = i + p[i];
            mid = i;
        }
    }
    return ret - 1;
}
}  // namespace manacher
using namespace manacher;
