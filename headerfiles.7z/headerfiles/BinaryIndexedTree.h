#pragma once

#include <cstring>
namespace binaryindexedtree {
using namespace std;
#define fastcall __attribute__((optimize("-O3")))
#define IL __inline__ __attribute__((always_inline))
template <typename T, int maxn>
class BinaryIndexedTree {
public:
    fastcall IL void init(const int &n) {
        this->n = n;
        memset(C, 0, sizeof(C));
        return;
    }
    fastcall IL void add(int p, const T &x) {
        while (p <= n) {
            C[p] += x;
            p += lowbit(p);
        }
        return;
    }
    fastcall IL T sum(int num) const {
        T ret = 0;
        while (num) {
            ret += C[num];
            num -= lowbit(num);
        }
        return ret;
    }

private:
    T C[maxn];
    int n;
    fastcall IL int lowbit(const int &num) const { return num & (-num); }
};
template <int maxn>
using BITInt = BinaryIndexedTree<int, maxn>;
template <int maxn>
using BITLongLong = BinaryIndexedTree<long long, maxn>;
}  // namespace binaryindexedtree
using namespace binaryindexedtree;
