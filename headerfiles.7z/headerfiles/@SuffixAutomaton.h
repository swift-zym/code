#pragma once

#include <unordered_map>
#include <cstring>
#include <vector>
namespace suffixautomaton {
using namespace std;
template <typename T, int maxn>
class SuffixAutomaton {
public:
    SuffixAutomaton(void) { init(); }
    inline void init(void) {
        memset(S, 0, sizeof(S));
        S[0] = (0, -1);
        size = 1;
    }
    inline void extend(const T &ch) {
        int c = size++;
        S[c].len = S[last].len + 1;
        int p = last;
        for (p = last; p != -1 && !S[p].nxt.count(ch); p = S[p].link) S[p].nxt[ch] = c;
        if (p == -1)
            S[size - 1].link = 0;
        else {
            int q = S[p].nxt[ch];
            if (S[p].len + 1 == S[q].len)
                S[c].link = q;
            else {
                int copy = size++;
                S[copy] = (S[p].len + 1, S[q].link);
                S[copy].nxt = S[q].nxt;
                for (; p != -1 && S[p].nxt[ch] == q; p = S[p].link) S[p].nxt[ch] = copy;
                S[c].link = S[q].link = copy;
            }
        }
        last = c;
        return;
    }
    inline void build(const vector<T> &vec) {
        for (int i = 0; i < vec.size(); i++) extend(vec[i]);
        return;
    }

private:
    struct node {
        node(const int &len = 0, const int &link = 0) : len(len), link(link) { nxt.clear(); }
        int len, link;
        unordered_map<T, int> nxt;
    };
    node S[maxn << 1];
    int size, last;
};
}  // namespace suffixautomaton
using namespace suffixautomaton;
