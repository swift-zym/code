#pragma once

#include <climits>
#include <vector>
namespace scapegoattree {
using namespace std;
#define fastcall __attribute__((optimize("-O3")))
#define IL __inline__ __attribute__((always_inline))
template <typename T, int maxn>
class ScapeGoatTree {
public:
    ScapeGoatTree(void) : tot(0), top(0), root(0) {}
    fastcall IL int getrank(const T &v) const {
        int p = root, rank = 1;
        while (p) {
            if (v <= val[p])
                p = ls[p];
            else
                rank += vaild[ls[p]] + !del[p], p = rs[p];
        }
        return rank;
    }
    fastcall IL T getkth(int k) const {
        if (k < 1)
            return INT_MIN;
        if (k > vaild[root])
            return INT_MAX;
        int p = root;
        while (p) {
            if (vaild[ls[p]] + 1 == k && !del[p])
                return val[p];
            if (vaild[ls[p]] >= k)
                p = ls[p];
            else
                k -= vaild[ls[p]] + !del[p], p = rs[p];
        }
        return (T)0;
    }
    fastcall void insert(const T &v) {
        int p = ins(root, 0, v);
        if (p) {
            if (p == root)
                rebuild(root);
            else {
                int father = fa[p];
                if (p == ls[father])
                    rebuild(ls[father]);
                else
                    rebuild(rs[father]);
            }
        }
        return;
    }
    fastcall IL void remove(const T &v) {
        delkth(root, getrank(v));
        if (vaild[root] < size[root] * alpha)
            rebuild(root);
        return;
    }
    fastcall IL T pre(const T &v) const { return getkth(getrank(v) - 1); }
    fastcall IL T suc(const T &v) const { return getkth(getrank(v + 1)); }

private:
    static constexpr double alpha = 0.75;
    int tot, top, root, stack[maxn];
    int ls[maxn], rs[maxn], fa[maxn];
    int vaild[maxn], size[maxn];
    bool del[maxn];
    T val[maxn];
    fastcall IL int newnode(const T &v, const int &father) {
        int p = top ? stack[top--] : ++tot;
        ls[p] = rs[p] = 0;
        del[p] = false;
        vaild[p] = size[p] = 1;
        fa[p] = father;
        val[p] = v;
        return p;
    }
    fastcall IL void maintain(const int &p) {
        vaild[p] = vaild[ls[p]] + vaild[rs[p]] + !del[p];
        size[p] = size[ls[p]] + size[rs[p]] + 1;
        return;
    }
    fastcall IL bool unbalance(const int &p) {
        return size[ls[p]] > size[p] * alpha || size[rs[p]] > size[p] * alpha;
    }
    fastcall void dfs(const int &p, vector<int> &v) {
        if (ls[p])
            dfs(ls[p], v);
        if (!del[p])
            v.push_back(p);
        else
            stack[++top] = p;
        if (rs[p])
            dfs(rs[p], v);
        return;
    }
    fastcall int build(const int &l, const int &r, const vector<int> &v) {
        if (l > r)
            return 0;
        int mid = (l + r) >> 1;
        int p = v[mid];
        ls[p] = build(l, mid - 1, v);
        rs[p] = build(mid + 1, r, v);
        fa[ls[p]] = fa[rs[p]] = p;
        maintain(p);
        return p;
    }
    fastcall IL void rebuild(int &p) {
        vector<int> v;
        int father = fa[p];
        dfs(p, v);
        p = build(0, v.size() - 1, v);
        fa[p] = father;
        return;
    }
    fastcall int ins(int &p, const int &father, const T &v) {
        if (!p) {
            p = newnode(v, father);
            return 0;
        }
        int ret;
        if (v <= val[p])
            ret = ins(ls[p], p, v);
        else
            ret = ins(rs[p], p, v);
        maintain(p);
        if (unbalance(p))
            ret = p;
        return ret;
    }
    fastcall void delkth(const int &p, const int &k) {
        vaild[p]--;
        if (!del[p] && k == vaild[ls[p]] + !del[p]) {
            del[p] = true;
            return;
        }
        if (k <= vaild[ls[p]])
            delkth(ls[p], k);
        else
            delkth(rs[p], k - vaild[ls[p]] - !del[p]);
        return;
    }
};
}  // namespace scapegoattree
using namespace scapegoattree;
