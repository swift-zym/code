#pragma once

#include <cstring>
#include <deque>
namespace bellmanford {
using namespace std;
template <typename T, int maxn, int R = 200, int dist = 10>
class BellmanFord {
public:
    BellmanFord(void) { init(); }
    inline void init(void) {
        memset(G, 0, sizeof(G));
        memset(head, 0, sizeof(head));
        cnt = 0;
        return;
    }
    inline void AddEdge(const int &u, const int &v, const T &val) {
        G[++cnt].to = v;
        G[cnt].nxt = head[u];
        G[cnt].val = val;
        head[u] = cnt;
        return;
    }
    T d[maxn];
    int p[maxn];
    inline void bellmanford(const int &s = 1) {
        deque<int> Q;
        memset(d, 0x3f, sizeof(d));
        memset(inq, false, sizeof(inq));
        d[s] = 0, inq[s] = true;
        memset(c, 0, sizeof(c));
        memset(p, 0, sizeof(p));
        Q.push_front(s);
        while (!Q.empty()) {
            int u = Q.front();
            Q.pop_front();
            inq[u] = false;
            for (int i = head[u]; i; i = G[i].nxt)
                if (d[G[i].to] > d[u] + G[i].val) {
                    d[G[i].to] = d[u] + G[i].val;
                    p[G[i].to] = i;
                    if (!inq[G[i].to]) {
                        inq[G[i].to] = true;
                        if (c[G[i].to] && c[G[i].to] < R) {
                            Q.push_front(G[i].to);
                            c[G[i].to]++;
                        } else {
                            if (!Q.size())
                                Q.push_back(G[i].to);
                            else if (d[*(Q.begin())] >= d[G[i].to] - dist)
                                Q.push_front(G[i].to);
                            else
                                Q.push_back(G[i].to);
                            if (!c[G[i].to])
                                c[G[i].to] = 1;
                        }
                    }
                }
        }
        return;
    }
    struct edge {
        int to, nxt;
        T val;
    };
    edge G[maxn];
    int head[maxn], cnt;

private:
    bool inq[maxn];
    int c[maxn];
};
}  // namespace bellmanford
using namespace bellmanford;

#include <algorithm>
#include <iostream>
#include <cassert>
#include <cstring>
#include <climits>
#include <string>
#include <vector>
namespace bigint {
using namespace std;
#define fastcall __attribute__((optimize("-O3")))
#define IL __inline__ __attribute__((always_inline))
class BigInt {
public:
    BigInt(long long num = 0) : f(true) { *this = num; }
    BigInt(const string &str) : f(true) { *this = str; }
    fastcall IL friend std::istream &operator>>(std::istream &in, BigInt &x) {
        string str;
        if (!(in >> str))
            return in;
        if (str[0] == '-')
            x.f = false, str = str.substr(1);
        x = str;
        return in;
    }
    fastcall IL friend std::ostream &operator<<(std::ostream &out, const BigInt &x) {
        if (!x.sign())
            out << '-';
        out << x.s.back();
        for (int i = x.s.size() - 2; i >= 0; i--) {
            char buf[20];
            sprintf(buf, "%01d", x.s[i]);
            for (int j = 0; j < strlen(buf); j++) out << buf[j];
        }
        return out;
    }
    fastcall IL BigInt operator=(long long num) {
        if (num < 0)
            f = false, num = -num;
        s.clear();
        do {
            s.push_back(num % base);
            num /= base;
        } while (num > 0);
        return *this;
    }
    fastcall IL BigInt operator=(string str) {
        s.clear();
        if (str[0] == '-')
            str = str.substr(1), f = false;
        int x, len = (str.length() - 1) / size + 1;
        for (int i = 0; i < len; i++) {
            int end = str.length() - i * size;
            int start = max(0, end - size);
            sscanf(str.substr(start, end - start).c_str(), "%d", &x);
            s.push_back(x);
        }
        return *this;
    }
    fastcall IL void reset(void) {
        f = true;
        s.clear();
        return;
    }
    fastcall IL bool sign(void) const { return f; }
    fastcall IL int length(void) const { return s.size(); }
    fastcall IL int operator[](const int &p) const { return s[p]; }
    fastcall IL bool operator<(const BigInt &rhs) const { return cmp(*this, rhs) == -1; }
    fastcall IL bool operator>(const BigInt &rhs) const { return cmp(*this, rhs) == 1; }
    fastcall IL bool operator<=(const BigInt &rhs) const { return cmp(*this, rhs) != 1; }
    fastcall IL bool operator>=(const BigInt &rhs) const { return cmp(*this, rhs) != -1; }
    fastcall IL bool operator==(const BigInt &rhs) const { return !cmp(*this, rhs); }
    fastcall IL bool operator!=(const BigInt &rhs) const { return cmp(*this, rhs); }
    static fastcall IL BigInt abs(BigInt num) {
        num.f = true;
        return num;
    }
    fastcall IL explicit operator bool() const { return *this != 0; }
    fastcall IL explicit operator long long() const {
        long long ret = 0;
        for (int i = length() - 1; i >= 0; i--) ret = ((ret << 3) + (ret << 1) + s[i]);
        if (!sign())
            ret *= -1;
        return ret;
    }
    fastcall IL BigInt operator-() const {
        BigInt ret = *this;
        ret.f = !f;
        return ret;
    }
    fastcall IL BigInt operator+(const BigInt &num) const {
        int s = ((!*this) << 1) + (!num);
        switch (s) {
            case 0:
                break;
            case 1:
                return *this;
                break;
            case 2:
                return num;
                break;
            case 3:
                return 0;
                break;
            default:
                break;
        }
        BigInt ret;
        ret.reset();
        if (sign() != num.sign()) {
            if (*this == -num)
                return 0;
            BigInt tmp1 = abs(*this), tmp2 = abs(num);
            if (tmp1 > tmp2) {
                ret = tmp1 - tmp2;
                ret.f = sign();
            } else {
                ret = tmp2 - tmp1;
                ret.f = num.sign();
            }
            return ret;
        }
        if (sign() == num.sign())
            ret.f = sign();
        int len = max(length(), num.length()), x;
        for (int i = 0; i < len; i++) {
            x = 0;
            if (i < length())
                x += this->s[i];
            if (i < num.length())
                x += num[i];
            ret.s.push_back(x);
        }
        ret.maintain();
        return ret;
    }
    fastcall BigInt operator-(const BigInt &num) const {
        if (*this == num)
            return 0;
        int s = ((!*this) << 1) + (!num);
        switch (s) {
            case 0:
                break;
            case 1:
                return *this;
                break;
            case 2:
                return -num;
                break;
            case 3:
                return 0;
                break;
            default:
                break;
        }
        BigInt ret;
        ret.reset();
        int stat = (sign() << 1) + num.sign();
        BigInt tmp1, tmp2;
        tmp1 = abs(*this), tmp2 = abs(num);
        switch (stat) {
            case 0:
                return tmp2 - tmp1;
                break;
            case 1:
                return -(tmp1 + tmp2);
                break;
            case 2:
                return tmp1 + tmp2;
                break;
            case 3:
                if (tmp1 < tmp2)
                    return -(num - *this);
                break;
            default:
                break;
        }
        for (int i = 0; i < length(); i++) {
            ret.s.push_back(this->s[i]);
            if (i < num.length())
                ret.s[i] -= num[i];
        }
        for (int i = 0; i < length() - 1; i++)
            if (ret[i] < 0)
                ret.s[i] += base, ret.s[i + 1]--;
        ret.maintain();
        return ret;
    }
    fastcall IL BigInt operator*(const BigInt &num) const {
        if (!*this || !num)
            return 0;
        int lim = 1;
        while (lim < (length() << 1)) lim <<= 1;
        while (lim < (num.length() << 1)) lim <<= 1;
        vector<int> r;
        getvec(r, lim);
        vector<int> a = s, b = num.s;
        a.resize(lim);
        b.resize(lim);
        NTT(a, lim, r);
        NTT(b, lim, r);
        vector<int> c;
        c.clear();
        for (int i = 0; i < lim; i++) c.push_back(((long long)a[i] * b[i]) % mod);
        NTT(c, lim, r, true);
        BigInt ret;
        ret.reset();
        ret.s.push_back(c[lim - 1]);
        for (int i = 0; i < lim - 1; i++) ret.s.push_back(c[i]);
        ret.f = (sign() + num.sign()) ^ 1;
        ret.maintain();
        return ret;
    }
    fastcall IL BigInt operator/(const BigInt &num) const {
        if (num == 0) {
            assert(false);
            return -1;
        }
        if (*this < num)
            return 0;
        BigInt inv = 1, t;
        bool flag = (sign() + num.sign()) ^ 1;
        BigInt numm = abs(num);
        if (abs(*this) <= (BigInt)LLONG_MAX && numm <= (BigInt)LLONG_MAX)
            return (long long)(*this) / (long long)(num);
        int fac = numm.length(), lim = numm.length() << 1;
        const static int times = 20;
        for (int i = 1; i <= times; i++) {
            t = 0;
            t.s.resize(fac + 1);
            t.s[fac] = 2;
            inv = inv * (t - numm * inv);
            fac *= 2;
            if (inv.length() > lim) {
                fac -= (inv.length() - lim);
                inv.cut(lim);
            }
        }
        BigInt ret = abs(*this) * inv;
        ret.cut(ret.length() - fac);
        ret.f = flag;
        return ret;
    }
    fastcall IL BigInt operator%(const BigInt &num) const { return *this - (*this / num) * num; }

private:
    const static int base = 10, size = 1;
    vector<int> s;
    bool f;
    fastcall IL void cut(const int &len) {
        int m = length() - len;
        for (int i = 0; i < len; i++) s[i] = s[i + m];
        for (int i = length() - 1; i >= len; i--) s.pop_back();
        return;
    }
    fastcall IL void maintain(void) {
        s.push_back(0);
        for (int i = 0; i < s.size(); i++) s[i + 1] += s[i] / base, s[i] %= base;
        while (!s[s.size() - 1]) s.pop_back();
        while (s[s.size() - 1]) {
            s.push_back(s[s.size() - 1] / base);
            s[s.size() - 2] %= base;
        }
        s.pop_back();
        return;
    }
    const static int mod = 998244353;
    static fastcall IL int Power(int b, int e, const int &mod) {
        int ret = 1;
        while (e) {
            if (e & 1)
                ret = ((long long)ret * b) % mod;
            e >>= 1;
            b = ((long long)b * b) % mod;
        }
        return ret;
    }
    static fastcall IL void getvec(vector<int> &r, const int &n) {
        r.clear();
        r.push_back(0);
        for (int i = 1; i < n; i++) r.push_back((r[i >> 1] >> 1) | ((i & 1) ? n >> 1 : 0));
        return;
    }
    static fastcall IL void NTT(vector<int> &v, const int &lim, const vector<int> &r,
                                const bool &opt = false) {
        for (int i = 0; i < lim; i++)
            if (r[i] < i)
                v[i] ^= v[r[i]] ^= v[i] ^= v[r[i]];
        int k, g, tmpg, t;
        for (int m = 2; m <= lim; m <<= 1) {
            k = m >> 1;
            g = Power(3, (mod - 1) / m, mod);
            for (int i = 0; i < lim; i += m) {
                tmpg = 1;
                for (int j = 0; j < k; j++, tmpg = ((long long)tmpg * g) % mod) {
                    t = ((long long)v[i + j + k] * tmpg) % mod;
                    v[i + j + k] = (v[i + j] - t + mod) % mod;
                    v[i + j] = (v[i + j] + t) % mod;
                }
            }
        }
        if (opt) {
            reverse(v.begin(), v.end());
            int inv = Power(lim, mod - 2, mod);
            for (int i = 0; i < lim; i++) v[i] = ((long long)v[i] * inv) % mod;
        }
        return;
    }
    static fastcall IL int cmp(const BigInt &a, const BigInt &b) {
        if (a.sign() != b.sign())
            return a.sign() ? 1 : -1;
        if (a.length() != b.length())
            return a.length() > b.length() ? 1 : -1;
        for (int i = a.length() - 1; i >= 0; i--)
            if (a[i] != b[i])
                return a[i] > b[i] ? 1 : -1;
        return 0;
    }
};
}  // namespace bigint
using namespace bigint;

#include <cstring>
namespace binaryindexedtree {
using namespace std;
template <typename T, int maxn>
class BinaryIndexedTree {
public:
    inline void init(const int &n) {
        this->n = n;
        memset(C, 0, sizeof(C));
        return;
    }
    inline void add(int p, const T &x) {
        while (p <= n) {
            C[p] += x;
            p += lowbit(p);
        }
        return;
    }
    inline T sum(int num) const {
        T ret = 0;
        while (num) {
            ret += C[num];
            num -= lowbit(num);
        }
        return ret;
    }

private:
    T C[maxn];
    int n;
    inline int lowbit(const int &num) const { return num & (-num); }
};
template <int maxn>
using BITInt = BinaryIndexedTree<int, maxn>;
template <int maxn>
using BITLongLong = BinaryIndexedTree<long long, maxn>;
}  // namespace binaryindexedtree
using namespace binaryindexedtree;

#include <cstring>
namespace binaryindexedtree2D {
using namespace std;
template <typename T, int maxn>
class BinaryIndexedTree2D {
public:
    inline void init(const int &n) {
        this->n = n;
        memset(C, 0, sizeof(C));
        return;
    }
    inline void add(int x, const int &y, const T &val) {
        while (x <= n) {
            int i = y;
            while (i <= n) {
                C[x][i] += val;
                i += lowbit(i);
            }
            x += lowbit(x);
        }
        return;
    }
    inline T sum(int x, const int &y) const {
        T ret = 0;
        while (x) {
            int i = y;
            while (i) {
                ret += C[x][i];
                i -= lowbit(i);
            }
            x -= lowbit(x);
        }
        return ret;
    }

private:
    T C[maxn][maxn];
    int n;
    inline int lowbit(const int &num) const { return num & (-num); }
};
template <int maxn>
using BITInt2D = BinaryIndexedTree2D<int, maxn>;
template <int maxn>
using BITLongLong2D = BinaryIndexedTree2D<long long, maxn>;
}  // namespace binaryindexedtree2D
using namespace binaryindexedtree2D;

#include <cstring>
namespace chainforwardstar {
using namespace std;
template <typename T, int maxn>
class ChainForwardStar {
public:
    ChainForwardStar(void) { init(); }
    void init(void) {
        memset(G, 0, sizeof(G));
        memset(head, 0, sizeof(head));
        cnt = 0;
        return;
    }
    void AddEdge(const int &u, const int &v, const T &val) {
        G[++cnt].from = u;
        G[++cnt].to = v;
        G[head[u]].front = cnt;
        G[cnt].nxt = head[u];
        G[cnt].val = val;
        head[u] = cnt;
        return;
    }
    void DeleteEdge(const int &p) {
        int a = G[p].front, b = G[p].nxt;
        if (!a)
            head[G[p].from] = b;
        else
            G[a].nxt = b;
        if (b)
            G[b].front = a;
        return;
    }
    struct edge {
        int from, to, front, nxt;
        T val;
    };
    edge G[maxn];
    int head[maxn], cnt;
};
}  // namespace chainforwardstar
using namespace chainforwardstar;

#include <cstring>
#include <queue>
namespace dijkstra {
using namespace std;
template <typename T, int maxn>
class Dijkstra {
public:
    Dijkstra(void) { init(); }
    inline void init(void) {
        memset(G, 0, sizeof(G));
        memset(head, 0, sizeof(head));
        cnt = 0;
        return;
    }
    inline void AddEdge(const int &u, const int &v, const T &val) {
        G[++cnt].to = v;
        G[cnt].nxt = head[u];
        G[cnt].val = val;
        head[u] = cnt;
        return;
    }
    T d[maxn];
    int p[maxn];
    inline void dijkstra(const int &s = 1) {
        priority_queue<Node> Q;
        memset(d, 0x3f, sizeof(d));
        d[s] = 0;
        memset(done, false, sizeof(done));
        memset(p, 0, sizeof(p));
        Q.push((Node){ 0, s });
        while (!Q.empty()) {
            int u = Q.top().u;
            Q.pop();
            if (done[u])
                continue;
            done[u] = true;
            for (int i = head[u]; i; i = G[i].nxt) {
                if (d[G[i].to] > d[u] + G[i].val) {
                    d[G[i].to] = d[u] + G[i].val;
                    p[G[i].to] = i;
                    Q.push((Node){ d[G[i].to], G[i].to });
                }
            }
        }
        return;
    }
    struct edge {
        int to, nxt;
        T val;
    };
    edge G[maxn];
    int head[maxn], cnt;

private:
    bool done[maxn];
    struct Node {
        T d;
        int u;
        bool operator<(const Node &x) const { return d > x.d; }
    };
};
}  // namespace dijkstra
using namespace dijkstra;

#include <cstring>
#include <queue>
namespace eulercircuit {
using namespace std;
template <int maxn>
class EulerCircuit {
public:
    EulerCircuit(void) { init(); }
    inline void init(const int &n = 0, const bool &f = false) {
        this->n = n;
        directed = f;
        memset(G, 0, sizeof(G));
        memset(deg, 0, sizeof(deg));
        memset(head, 0, sizeof(head));
        memset(this->f, 0, sizeof(this->f));
        cnt = 0;
        return;
    }
    inline void AddEdge(const int &u, const int &v) {
        G[++cnt].to = v;
        G[cnt].nxt = head[u];
        head[u] = cnt;
        deg[0][u]++, deg[1][v]++;
        f[u] = f[v] = true;
        return;
    }
    int ans[maxn], c;
    inline bool eulercircuit(void) {
        memset(stack, 0, sizeof(stack));
        memset(vis, 0, sizeof(vis));
        memset(tmp, 0, sizeof(tmp));
        if (directed) {
            for (int i = 1; i <= n; i++)
                if (deg[0][i] != deg[1][i])
                    return false;
        } else {
            for (int i = 1; i <= n; i++)
                if ((deg[0][i] & 1) || (deg[1][i] & 1))
                    return false;
        }
        tot = c = 0;
        for (int i = 1; i <= n; i++)
            if (f[i]) {
                stack[++tot] = i;
                break;
            }
        bool flag;
        int v = !directed, val = 0;
        while (tot) {
            flag = false;
            for (int i = head[stack[tot]]; i; i = G[i].nxt)
                if (!vis[((i - 1) >> v) + 1]) {
                    val++;
                    head[stack[tot]] = G[i].nxt;
                    flag = true;
                    vis[((i - 1) >> v) + 1] = 1;
                    stack[++tot] = G[i].to;
                    tmp[tot] = i;
                    if (v) {
                        tmp[tot] = ((i - 1) >> 1) + 1;
                        if (!(i & 1))
                            tmp[tot] = 1 + ~tmp[tot];
                    }
                    break;
                }
            if (!flag) {
                if (tot != 1)
                    ans[++c] = tmp[tot];
                tot--;
            }
        }
        for (int p = 1; (p << 1) <= c; p++) ans[p] ^= ans[c - p + 1] ^= ans[p] ^= ans[c - p + 1];
        return val == cnt >> v;
    }
    struct edge {
        int to, nxt;
    };
    edge G[maxn];
    int head[maxn], cnt;
    bool directed;
    int n;

private:
    bool vis[maxn], f[maxn];
    int stack[maxn], tot;
    int deg[2][maxn];
    int tmp[maxn];
};
}  // namespace eulercircuit
using namespace eulercircuit;

#include <cstring>
#include <queue>
namespace eulerjudge {
using namespace std;
template <int maxn>
class EulerJudge {
public:
    EulerJudge(void) { init(); }
    inline void init(const int &n = 0, const bool &f = false) {
        this->n = n;
        directed = f;
        memset(G, 0, sizeof(G));
        memset(deg, 0, sizeof(deg));
        memset(head, 0, sizeof(head));
        memset(this->f, 0, sizeof(this->f));
        cnt = 0;
        return;
    }
    inline void AddEdge(const int &u, const int &v) {
        G[++cnt].to = v;
        G[cnt].nxt = head[u];
        head[u] = cnt;
        deg[0][u]++, deg[1][v]++;
        f[u] = f[v] = true;
        return;
    }
    inline bool eulerjudge(bool circuit) {
        s.init(n);
        int fx, fy;
        for (int u = 1; u <= n; u++)
            for (int i = head[u]; i; i = G[i].nxt) {
                fx = s.find(u), fy = s.find(G[i].to);
                if (fx != fy)
                    s.fa[fx] = fy;
            }
        int cnt = 0;
        for (int i = 1; i <= n; i++)
            if (f[i] && s.fa[i] == i)
                cnt++;
        if (cnt > 1)
            return false;
        if (circuit) {
            if (directed) {
                for (int i = 1; i <= n; i++)
                    if (deg[0][i] == deg[1][i])
                        return false;
            } else {
                for (int i = 1; i <= n; i++)
                    if ((deg[0][i] & 1) || (deg[1][i] & 1))
                        return false;
            }
        } else {
            if (directed) {
                int c1 = 0, c2 = 0;
                for (int i = 1; i <= n; i++)
                    if (deg[0][i] > deg[1][i])
                        c1++;
                    else if (deg[0][i] < deg[1][i])
                        c2++;
                if (c1 != c2 || c1 > 1 || c2 > 1)
                    return false;
            } else {
                cnt = 0;
                for (int i = 1; i <= n; i++)
                    if ((deg[0][i] & 1) || (deg[1][i] & 1))
                        cnt++;
                if (cnt != 0 && cnt != 2)
                    return false;
            }
        }
        return true;
    }
    struct edge {
        int to, nxt;
    };
    edge G[maxn];
    int head[maxn], cnt;
    bool directed;
    int n;

private:
    class UnionFindSet {
    public:
        inline void init(const int &n) {
            memset(fa, 0, sizeof(fa));
            for (int i = 1; i <= n; i++) fa[i] = i;
            memset(rank, 0, sizeof(rank));
            return;
        }
        inline void Union(const int &u, const int &v) {
            int x = find(u), y = find(v);
            if (rank[x] < rank[y])
                fa[x] = y;
            else {
                fa[y] = x;
                if (rank[x] == rank[y])
                    rank[x]++;
            }
            return;
        }
        inline bool Find(const int &u, const int &v) { return this->find(u) == this->find(v); }
        int fa[maxn];
        int find(const int &u) { return fa[u] == u ? u : fa[u] = find(fa[u]); }

    private:
        int rank[maxn];
    };
    UnionFindSet s;
    bool vis[maxn], f[maxn];
    int deg[2][maxn];
};
}  // namespace eulerjudge
using namespace eulerjudge;

#include <cmath>
#include <unordered_map>
namespace exbsgs {
using namespace std;
template <typename T>
inline T multyply(T x, T y, T mod) {
    x %= mod, y %= mod;
    return ((x * y - (T)(((long double)x * y + 0.5) / mod) * mod) % mod + mod) % mod;
}
template <typename T>
inline T EXBSGS(const T &a, T b, T p) {
    T d = 1, v, cnt = 0, ta, tp;
    while (true) {
        ta = a, tp = p;
        while (ta ^= tp ^= ta ^= tp %= ta) continue;
        v = tp;
        if (v == 1)
            break;
        if (b % v)
            return -1;
        b /= v, p /= v, cnt++;
        d = multyply(d, a / v, p);
        if (b == d)
            return cnt;
    }
    unordered_map<T, int> M;
    M.clear();
    M[b] = 0;
    T t = b, sqrtp = ceil(sqrt(p)), m = 1;
    for (int i = 1; i <= sqrtp; i++) t = multyply(t, a, p), M[t] = i;
    t = d, ta = a;
    T e = sqrtp;
    while (e) {
        if (e & 1)
            m = (m * ta) % p;
        e >>= 1, ta = (ta * ta) % p;
    }
    for (int i = 1; i <= sqrtp; i++) {
        t = multyply(t, m, p);
        if (M.count(t))
            return ((i * sqrtp - M[t] + cnt) % p + p) % p;
    }
    return -1;
}
}  // namespace exbsgs
using namespace exbsgs;

namespace excrt {
using namespace std;
template <typename T, int maxn>
class EXCRT {
public:
    struct equation {
        T a, b;
    };
    equation e[maxn];
    int n, cnt;
    EXCRT(const int &n = 0) {
        init(n);
        return;
    }
    inline void init(const int &n) {
        cnt = 0;
        this->n = n;
        return;
    }
    inline void AddEquation(const T &a, const T &b) {
        e[++cnt] = (equation){ a, b };
        return;
    }
    inline T solve(void) const {
        T A = e[1].a, ans = e[1].b, l, x, o;
        for (int i = 2; i <= n; i++) {
            exgcd(A, e[i].a, o, x, l);
            if ((e[i].b - ans % e[i].a + e[i].a) % o)
                return -1;
            x = multyply(x, (((e[i].b - ans % e[i].a + e[i].a) % e[i].a) / o), e[i].a / o);
            ans += x * A;
            A *= (e[i].a / o);
            ans = (ans % A + A) % A;
        }
        return (ans % A + A) % A;
    }

private:
    void exgcd(const T &a, const T &b, T &g, T &x, T &y) const {
        if (b) {
            exgcd(b, a % b, g, y, x);
            y -= x * (a / b);
            return;
        }
        g = a, x = 1, y = 0;
        return;
    }
    inline T multyply(T x, T y, const T &mod) const {
        x %= mod, y %= mod;
        return ((x * y - (T)(((long double)x * y + 0.5) / mod) * mod) % mod + mod) % mod;
    }
};
}  // namespace excrt
using namespace excrt;

namespace exgcd {
using namespace std;
template <typename T>
void EXGCD(const T &a, const T &b, T &g, T &x, T &y) {
    if (b) {
        EXGCD(b, a % b, g, y, x);
        y -= x * (a / b);
        return;
    }
    g = a, x = 1, y = 0;
    return;
}
// ax + by = c
template <typename T>
inline bool Equation(const T &a, const T &b, const T &c, T &x, T &y) {
    T g = 0;
    EXGCD(a, b, g, x, y);
    if (c % g)
        return false;
    T t = b / g;
    x = ((x + t) * (c / g)) % t;
    if (x < 0)
        x += t;
    y = (c - a * x) / b;
    return true;
}
}  // namespace exgcd
using namespace exgcd;

#include <cstring>
namespace floyd {
using namespace std;
template <typename T, int maxn>
class Floyd {
public:
    inline void init(const int &n) {
        memset(d, 0x3f, sizeof(d));
        this->n = n;
        cnt = 0;
        return;
    }
    inline void AddEdge(int from, int to, int dist) {
        d[from][to] = dist;
        return;
    }
    inline void floyd(void) {
        for (int i = 1; i <= n; i++) d[i][i] = 0;
        for (int k = 1; k <= n; k++)
            for (int i = 1; i <= n; i++)
                if (d[i][k] != d[0][0])
                    for (int j = 1; j <= n; j++)
                        if (d[k][j] != d[0][0] && d[i][j] > d[i][k] + d[k][j])
                            d[i][j] = d[i][k] + d[k][j];
        return;
    }
    T d[maxn][maxn];

private:
    int n;
};
}  // namespace floyd
using namespace floyd;

#include <vector>
#include <string>
namespace hashclass {
using namespace std;
template <unsigned long long mod, unsigned long long base = 19260817>
class HashClass {
public:
    inline void init(const string &str) {
        h.clear();
        p.clear();
        h.push_back((unsigned long long)str[0]);
        p.push_back(1);
        for (int i = 1; i < str.length(); i++) {
            h.push_back(((h[i - 1] * base) % mod + str[i]) % mod);
            p.push_back((p[i - 1] * base) % mod);
        }
        return;
    }
    inline unsigned long long get_hash(const int &l, const int &r) const {
        if (l == 0)
            return h[r];
        return (h[r] - (h[l - 1] * p[r - l + 1]) % mod + mod) % mod;
    }

private:
    vector<unsigned long long> h, p;
};
}  // namespace hashclass
using namespace hashclass;

#include <cstring>
#include <queue>
namespace hlpp {
using namespace std;
template <typename T, int maxn>
class HLPP {
public:
    HLPP(void) { init(); }
    inline void init(void) {
        memset(G, 0, sizeof(G));
        memset(head, 0, sizeof(head));
        cnt = 1;
        return;
    }
    inline void AddEdge(const int &u, const int &v, const T &val) {
        addedge(u, v, val);
        addedge(v, u, 0);
        return;
    }
    inline T hlpp(const int &n, const int &s, const int &t) {
        static int h[maxn];
        memset(h, 0x3f, sizeof(h));
        static queue<int> Q;
        Q.push(t);
        h[t] = 0;
        int u;
        while (!Q.empty()) {
            u = Q.front();
            Q.pop();
            for (int i = head[u]; i; i = G[i].nxt)
                if (G[i ^ 1].val && h[G[i].to] > h[u] + 1)
                    h[G[i].to] = h[u] + 1, Q.push(G[i].to);
        }
        if (h[s] == h[0])
            return 0;
        h[s] = n;
        static T flow[maxn];
        static int gap[maxn];
        memset(flow, 0, sizeof(flow));
        memset(gap, 0, sizeof(gap));
        for (int i = 1; i <= n; i++)
            if (h[i] != h[0])
                gap[h[i]]++;
        static bool vis[maxn];
        memset(vis, 0, sizeof(vis));
        struct cmp {
            inline bool operator()(const int &a, const int &b) const { return h[a] < h[b]; }
        };
        static priority_queue<int, vector<int>, cmp> PQ;
        for (int i = head[s]; i; i = G[i].nxt)
            if (G[i].val) {
                flow[s] -= G[i].val, flow[G[i].to] += G[i].val;
                G[i ^ 1].val += G[i].val, G[i].val = 0;
                if (G[i].to != s && G[i].to != t && !vis[G[i].to])
                    PQ.push(G[i].to), vis[G[i].to] = true;
            }
        T v;
        bool flag;
        while (!PQ.empty()) {
            u = PQ.top();
            PQ.pop();
            vis[u] = false;
            while (true) {
                flag = false;
                if (!flow[u])
                    break;
                for (int i = head[u]; i; i = G[i].nxt) {
                    if (!G[i].val || h[u] != h[G[i].to] + 1)
                        continue;
                    v = min(G[i].val, flow[u]);
                    flow[u] -= v, flow[G[i].to] += v;
                    G[i].val -= v, G[i ^ 1].val += v;
                    if (G[i].to != s && G[i].to != t && !vis[G[i].to])
                        PQ.push(G[i].to), vis[G[i].to] = true;
                    if (!flow[u]) {
                        flag = true;
                        break;
                    }
                }
                if (flag)
                    break;
                if (!(--gap[h[u]]))
                    for (int i = 1; i <= n; i++)
                        if (i != s && i != t && h[i] > h[u] && h[i] <= n)
                            h[i] = n + 1;
                h[u] = h[0];
                for (int i = head[u]; i; i = G[i].nxt)
                    if (G[i].val && h[G[i].to] < h[u])
                        h[u] = h[G[i].to];
                gap[++h[u]]++;
            }
        }
        return flow[t];
    }

private:
    struct edge {
        int to, nxt;
        T val;
    };
    edge G[maxn << 1];
    int head[maxn], cnt;
    inline void addedge(const int &u, const int &v, const T &val) {
        G[++cnt].to = v;
        G[cnt].nxt = head[u];
        G[cnt].val = val;
        head[u] = cnt;
        return;
    }
};
}  // namespace hlpp
using namespace hlpp;

#include <climits>
#include <cstring>
#include <queue>
namespace hopcroftkarp {
using namespace std;
template <int maxn>
class HopcroftKarp {
public:
    HopcroftKarp() { init(); }
    inline void init(void) {
        memset(G, 0, sizeof(G));
        memset(head, 0, sizeof(head));
        cnt = 0;
        return;
    }
    inline void AddEdge(const int &u, const int &v) {
        G[++cnt].to = v;
        G[cnt].nxt = head[u];
        head[u] = cnt;
        return;
        return;
    }
    int pair_l[maxn], pair_r[maxn], n, m;
    inline int solve(const int &n, const int &m) {
        this->n = n, this->m = m;
        memset(pair_l, -1, sizeof(pair_l));
        memset(pair_r, -1, sizeof(pair_r));
        int c = 0;
        while (bfs())
            for (int u = 1; u <= n; u++)
                if (pair_l[u] == -1)
                    c += dfs(u);
        return c;
    }

private:
    struct edge {
        int to, nxt;
    };
    int cnt;
    edge G[maxn << 1];
    int head[maxn];
    bool vis[maxn];
    int dist[2][maxn], d;
    inline bool bfs(void) {
        memset(vis, 0, sizeof(vis));
        memset(dist, -1, sizeof(dist));
        static queue<int> Q;
        d = INT_MAX;
        for (int i = 1; i <= n; i++)
            if (pair_l[i] == -1)
                dist[0][i] = 0, Q.push(i);
        while (!Q.empty()) {
            int u = Q.front();
            Q.pop();
            if (dist[0][u] <= d)
                for (int i = head[u]; i; i = G[i].nxt)
                    if (dist[1][G[i].to] == -1) {
                        dist[1][G[i].to] = dist[0][u] + 1;
                        if (pair_r[G[i].to] == -1)
                            d = dist[1][G[i].to];
                        else
                            dist[0][pair_r[G[i].to]] = dist[1][G[i].to] + 1, Q.push(pair_r[G[i].to]);
                    }
        }
        return d != INT_MAX;
    }
    bool dfs(const int &u) {
        for (int i = head[u]; i; i = G[i].nxt)
            if (!vis[G[i].to] && dist[1][G[i].to] == dist[0][u] + 1) {
                vis[G[i].to] = true;
                if (pair_r[G[i].to] != -1 && dist[1][G[i].to] == d)
                    continue;
                if (pair_r[G[i].to] == -1 || dfs(pair_r[G[i].to])) {
                    pair_l[u] = G[i].to;
                    pair_r[G[i].to] = u;
                    return true;
                }
            }
        return false;
    }
};
}  // namespace hopcroftkarp
using namespace hopcroftkarp;

namespace inverse {
using namespace std;
template <typename T>
void exgcd(const T &a, const T &b, T &g, T &x, T &y) {
    if (b) {
        exgcd(b, a % b, g, y, x);
        y -= x * (a / b);
        return;
    }
    g = a, x = 1, y = 0;
    return;
}
template <typename T>
inline T Inverse(const T &a, const T &p) {
    T g, x, y;
    exgcd(a, p, g, x, y);
    x %= p;
    if (x < 0)
        x += p;
    return x;
}
}  // namespace inverse
using namespace inverse;

#include <cctype>
#include <cstdio>
namespace io {
using namespace std;
struct istream {
#define M (1 << 25)
    int f;
    char buf[M], *ch = buf - 1;
    inline istream() { fread(buf, 1, M, stdin); }
    inline istream &operator>>(int &x) {
        f = 1;
        while (!isdigit(*++ch))
            if (*ch == '-')
                f = -1;
        for (x = *ch & 15; isdigit(*++ch);) x = x * 10 + (*ch & 15);
        x *= f;
        return *this;
    }
    inline istream &operator>>(long long &x) {
        f = 1;
        while (!isdigit(*++ch))
            if (*ch == '-')
                f = -1;
        for (x = *ch & 15; isdigit(*++ch);) x = x * 10 + (*ch & 15);
        x *= f;
        return *this;
    }
    inline istream &operator>>(char &c) {
        c = *++ch;
        return *this;
    }
#undef M
} cin;
struct ostream {
#define M (1 << 25)
    char buf[M], *ch = buf - 1;
#define endl (char)10
    inline ostream &operator<<(int x) {
        if (!x) {
            *++ch = '0';
            return *this;
        }
        if (x < 0) {
            x = -x;
            *++ch = '-';
        }
        static int S[10], *top;
        top = S;
        while (x) {
            *++top = x % 10 ^ 48;
            x /= 10;
        }
        for (; top != S; --top) *++ch = *top;
        return *this;
    }
    inline ostream &operator<<(long long x) {
        if (!x) {
            *++ch = '0';
            return *this;
        }
        if (x < 0) {
            x = -x;
            *++ch = '-';
        }
        static int S[10], *top;
        top = S;
        while (x) {
            *++top = x % 10 ^ 48;
            x /= 10;
        }
        for (; top != S; --top) *++ch = *top;
        return *this;
    }
    inline ostream &operator<<(const char &x) {
        *++ch = x;
        return *this;
    }
    inline ~ostream() { fwrite(buf, 1, ch - buf + 1, stdout); }
#undef M
} cout;
}  // namespace io
using namespace io;

#include <vector>
#include <string>
namespace kmp {
using namespace std;
vector<int> nxt, tmp;
inline int KMP(const string &t, const string &p, vector<int> &v = tmp) {
    int n = t.length(), m = p.length();
    nxt.clear();
    nxt.push_back(0);
    nxt.push_back(0);
    int q = 0;
    for (int i = 1; i < m; i++) {
        while (q && p[q] != p[i]) q = nxt[q];
        if (p[q] == p[i])
            q++;
        nxt.push_back(q);
    }
    q = 0;
    v.clear();
    for (int i = 0; i < n; i++) {
        while (q && p[q] != t[i]) q = nxt[q];
        if (t[i] == p[q])
            q++;
        if (q == m)
            v.push_back(i - m + 1), q = 0;
    }
    return v.size();
}
}  // namespace kmp
using namespace kmp;

#include <algorithm>
#include <cstring>
namespace kruskal {
using namespace std;
template <typename T, int maxn>
class Kruskal {
public:
    inline void init(const int &n) {
        this->n = n;
        cnt = 0;
        return;
    }
    inline void AddEdge(const int &u, const int &v, const T &val) {
        G[++cnt].from = u;
        G[cnt].to = v;
        G[cnt].val = val;
        return;
    }
    inline T kruskal(void) {
        memset(used, false, sizeof(used));
        T ans = 0;
        int num = 0;
        sort(G + 1, G + cnt + 1);
        s.init(n);
        for (int i = 1; i <= cnt; i++) {
            if (!s.Find(G[i].from, G[i].to)) {
                used[i] = true;
                ans += G[i].val;
                s.Union(G[i].from, G[i].to);
                if (++num == n - 1)
                    break;
            }
        }
        return ans;
    }
    bool used[maxn];
    struct edge {
        int from, to;
        T val;
        inline const bool operator<(const edge &p) const { return val < p.val; }
    };
    int cnt;
    edge G[maxn];

private:
    int n;
    class UnionFindSet {
    public:
        inline void init(const int &n) {
            memset(fa, 0, sizeof(fa));
            for (int i = 1; i <= n; i++) fa[i] = i;
            memset(rank, 0, sizeof(rank));
            return;
        }
        inline void Union(const int &u, const int &v) {
            int x = find(u), y = find(v);
            if (rank[x] < rank[y])
                fa[x] = y;
            else {
                fa[y] = x;
                if (rank[x] == rank[y])
                    rank[x]++;
            }
            return;
        }
        inline bool Find(const int &u, const int &v) { return this->find(u) == this->find(v); }
        int fa[maxn];

    private:
        int find(const int &u) { return fa[u] == u ? u : fa[u] = find(fa[u]); }
        int rank[maxn];
    };
    UnionFindSet s;
};
}  // namespace kruskal
using namespace kruskal;

#include <cmath>
#include <cstring>
namespace lowestcommonancestor {
using namespace std;
template <typename T, int maxn>
class LowestCommonAncestor {
public:
    LowestCommonAncestor(void) {
        for (int i = 1; i < maxn; i++) lg[i] = lg[i - 1] + ((1 << lg[i - 1]) == i);
        clear();
        return;
    }
    inline void AddEdge(const int &u, const int &v, const T &val = 1) {
        add(u, v, val);
        add(v, u, val);
        return;
    }
    inline void clear(void) {
        cnt = n = r = 0;
        memset(depth, 0, sizeof(depth));
        memset(head, 0, sizeof(head));
        memset(anc, 0, sizeof(anc));
        memset(G, 0, sizeof(G));
        memset(d, 0, sizeof(d));
        return;
    }
    inline void preprocess(const int &root, const int &n) {
        this->n = n;
        r = root;
        depth[0] = d[0] = 0;
        build(r);
        for (int j = 1; j <= (int)log2(maxn); j++) {
            for (int i = 1; i <= n; i++) {
                if (j > depth[i])
                    continue;
                anc[i][j] = anc[anc[i][j - 1]][j - 1];
            }
        }
        return;
    }
    inline int LCA(int x, int y) {
        if (depth[x] < depth[y])
            x ^= y ^= x ^= y;
        while (depth[x] > depth[y]) x = anc[x][lg[depth[x] - depth[y]] - 1];
        if (x == y)
            return x;
        for (int i = lg[depth[x]] - 1; i >= 0; i--)
            if (anc[x][i] != anc[y][i])
                x = anc[x][i], y = anc[y][i];
        return anc[x][0];
    }
    inline T dist(const int &u, const int &v) { return d[u] + d[v] - (d[LCA(u, v)] << 1); }

private:
    int n, r, maxlg;
    int anc[maxn][(int)(log2(maxn) + 1)];
    int depth[maxn], lg[maxn];
    T d[maxn];
    struct node {
        int to, nxt;
        T val;
    };
    int cnt;
    node G[maxn << 1];
    int head[maxn];
    inline void add(const int &u, const int &v, const T &val) {
        G[++cnt].to = v;
        G[cnt].nxt = head[u];
        G[cnt].val = val;
        head[u] = cnt;
        return;
    }
    void build(const int &u, const int &fa = 0) {
        anc[u][0] = fa;
        depth[u] = depth[fa] + 1;
        for (int i = head[u]; i; i = G[i].nxt)
            if (G[i].to != fa) {
                d[G[i].to] = d[u] + G[i].val;
                build(G[i].to, u);
            }
        return;
    }
};
template <typename T, int maxn>
using LCA = LowestCommonAncestor<T, maxn>;
}  // namespace lowestcommonancestor
using namespace lowestcommonancestor;

#include <vector>
#include <string>
namespace manacher {
using namespace std;
vector<int> tmp;
inline int Manacher(const string &str, vector<int> &p = tmp) {
    string a;
    int n = str.length();
    a.resize((n << 1) + 1);
    a[0] = '#';
    for (int i = 0; i < n; i++) {
        a[(i << 1) + 1] = str[i];
        a[(i << 1) + 2] = '#';
    }
    n = a.length();
    int ret = 0, mid, r = 0;
    for (int i = 0; i < n; i++) {
        if (i < r)
            p.push_back(min(p[(mid << 1) - i], p[mid] + mid - i));
        else
            p.push_back(1);
        while (i + p[i] < n && i - p[i] >= 0 && a[i + p[i]] == a[i - p[i]]) p[i]++;
        if (p[i] > ret)
            ret = p[i];
        if (i + p[i] > r) {
            r = i + p[i];
            mid = i;
        }
    }
    return ret - 1;
}
}  // namespace manacher
using namespace manacher;

#include <cassert>
#include <cstring>
namespace matrix {
using namespace std;
template <typename T, int maxn>
class Matrix {
public:
    Matrix() { memset(val, 0, sizeof(val)); }
    inline void init(const int &n, const int &m) {
        this->n = n, this->m = m;
        return;
    }
    inline T *operator[](const int &p) { return val[p]; }
    inline int getrow(void) { return n; }
    inline int getcol(void) { return m; }
    inline Matrix operator+(const Matrix &a) const {
        assert(this->n == a.n && this->m == a.m);
        Matrix ret;
        ret.init(this->n, this->m);
        for (int i = 1; i <= ret.n; i++)
            for (int j = 1; j <= ret.m; j++) ret.val[i][j] = this->val[i][j] + a.val[i][j];
        return ret;
    }
    inline Matrix operator-(const Matrix &a) const {
        assert(this->n == a.n && this->m == a.m);
        Matrix ret;
        ret.init(this->n, this->m);
        for (int i = 1; i <= ret.n; i++)
            for (int j = 1; j <= ret.m; j++) ret.val[i][j] = this->val[i][j] - a.val[i][j];
        return ret;
    }
    inline Matrix operator*(Matrix a) const {
        assert(this->m == a.n);
        int n = this->n, m = a.m, p = this->m;
        Matrix ret;
        ret.init(n, m);
        int m1 = m - m % 8;
        for (int i = 1; i <= n; ++i) {
            for (int k = 1; k <= p; ++k) {
                T *y = a[k];
                T x = this->val[i][k], *z = ret[i];
                for (int j = 8; j <= m1; j += 8) {
                    z[1] += x * y[1], z[2] += x * y[2], z[3] += x * y[3], z[4] += x * y[4], z[5] += x * y[5],
                        z[6] += x * y[6], z[7] += x * y[7], z[8] += x * y[8];
                    z += 8, y += 8;
                }
                y = a[k];
                for (int j = m1 + 1; j <= m; ++j) ret[i][j] += x * y[j];
            }
        }
        return ret;
    }
    inline Matrix operator+=(const Matrix &a) {
        *this = *this + a;
        return *this;
    }
    inline Matrix operator-=(const Matrix &a) {
        *this = *this - a;
        return *this;
    }
    inline Matrix operator*=(const Matrix &a) {
        *this = *this * a;
        return *this;
    }

private:
    T val[maxn][maxn];
    int n, m;
};
}  // namespace matrix
using namespace matrix;

#include <cstring>
#include <vector>
namespace minimumcycle {
using namespace std;
template <typename T, int maxn>
class MinimumCycle {
public:
    MinimumCycle(void) {
        memset(val, 0x3f, sizeof(val));
        memset(d, 0, sizeof(d));
        n = 0;
    }
    inline void init(const int &n) {
        memset(val, 0x3f, sizeof(val));
        memset(d, 0, sizeof(d));
        this->n = n;
        return;
    }
    inline void AddEdge(const int &u, const int &v, const int &val) {
        if (this->val[u][v] > val)
            this->val[u][v] = this->val[v][u] = val;
        return;
    }
    inline int solve(vector<int> &path = tmp) {
        static T pre[maxn][maxn];
        memset(pre, 0, sizeof(pre));
        path.clear();
        for (int i = 1; i <= n; i++)
            for (int j = 1; j <= n; j++) pre[i][j] = i;
        for (int i = 1; i <= n; i++)
            for (int j = i; j <= n; j++) d[i][j] = d[j][i] = val[i][j];
        int ret = val[0][0], u;
        for (int k = 1; k <= n; k++) {
            for (int i = 1; i < k; i++)
                for (int j = i + 1; j < k; j++)
                    if (d[i][j] != val[0][0] && val[i][k] != val[0][0] && val[k][j] != val[0][0] &&
                        d[i][j] + val[i][k] + val[k][j] < ret) {
                        ret = d[i][j] + val[i][k] + val[k][j];
                        u = j;
                        path.clear();
                        while (u != i) {
                            path.push_back(u);
                            u = pre[i][u];
                        }
                        path.push_back(i);
                        path.push_back(k);
                    }
            for (int i = 1; i <= n; i++)
                if (d[i][k] != val[0][0])
                    for (int j = 1; j <= n; j++)
                        if (d[k][j] != val[0][0] && d[i][j] > d[i][k] + d[k][j]) {
                            d[i][j] = d[i][k] + d[k][j];
                            pre[i][j] = pre[k][j];
                        }
        }
        return ret;
    }

private:
    T d[maxn][maxn], val[maxn][maxn];
    int n;
    static vector<int> tmp;
};
}  // namespace minimumcycle
using namespace minimumcycle;

#include <algorithm>
#include <cstring>
#include <cfloat>
namespace minimumcyclemean {
using namespace std;
template <typename T, int maxn>
class MinimumCycleMean {
public:
    MinimumCycleMean(void) { init(); }
    inline void init(void) {
        memset(G, 0, sizeof(G));
        cnt = 0;
        return;
    }
    inline void AddEdge(const int &u, const int &v, const T &val) {
        G[++cnt].from = u;
        G[cnt].to = v;
        G[cnt].val = val;
        return;
    }
    inline double minimumcyclemean(const int &n) {
        memset(F, 0, sizeof(F));
        int cur = 0;
        for (int i = 1; i <= n; i++) {
            fill(F[cur] + 1, F[cur] + n + 1, DBL_MAX);
            for (int j = 1; j <= cnt; j++)
                F[cur][G[j].to] = min(F[cur][G[j].to], F[cur ^ 1][G[j].from] + G[j].val);
            cur ^= 1;
        }
        memcpy(F[2], F[cur ^ 1], sizeof(F[cur ^ 1]));
        memset(F[cur ^ 1], 0, sizeof(F[cur ^ 1]));
        memset(maxv, 0, sizeof(maxv));
        for (int i = 1; i <= n; i++) maxv[i] = F[2][i] / n;
        for (int i = 1; i <= n; i++) {
            fill(F[cur] + 1, F[cur] + n + 1, DBL_MAX);
            for (int j = 1; j <= cnt; j++)
                F[cur][G[j].to] = min(F[cur][G[j].to], F[cur ^ 1][G[j].from] + G[j].val);
            for (int j = 1; j <= n; j++) maxv[j] = max(maxv[j], (F[2][j] - F[cur][j]) / (n - i));
            cur ^= 1;
        }
        double ret = DBL_MAX;
        for (int i = 1; i <= n; i++) ret = min(ret, maxv[i]);
        return ret;
    }
    struct edge {
        int from, to;
        T val;
    };
    edge G[maxn];
    int cnt;

private:
    double F[3][maxn], maxv[maxn];
};
}  // namespace minimumcyclemean
using namespace minimumcyclemean;

#include <cstring>
namespace negativecycle {
using namespace std;
template <typename T, int maxn>
class NegativeCycle {
public:
    NegativeCycle(void) { init(); }
    inline void init(void) {
        memset(G, 0, sizeof(G));
        memset(head, 0, sizeof(head));
        cnt = 0;
        return;
    }
    inline void AddEdge(const int &u, const int &v, const T &val) {
        G[++cnt].to = v;
        G[cnt].nxt = head[u];
        G[cnt].val = val;
        head[u] = cnt;
        return;
    }
    inline bool negativecycle(const int &n) {
        f = false;
        memset(inq, false, sizeof(inq));
        memset(d, 0, sizeof(d));
        for (int i = 1; i <= n; i++) {
            dfs(i);
            if (f)
                break;
        }
        return f;
    }
    struct edge {
        int to, nxt;
        T val;
    };
    edge G[maxn];
    int head[maxn], cnt;

private:
    T d[maxn];
    bool inq[maxn], f;
    void dfs(const int &u) {
        if (f)
            return;
        inq[u] = true;
        for (int i = head[u]; i; i = G[i].nxt) {
            if (f)
                return;
            if (d[G[i].to] > d[u] + G[i].val) {
                if (inq[G[i].to]) {
                    f = true;
                    return;
                }
                d[G[i].to] = d[u] + G[i].val;
                dfs(G[i].to);
            }
        }
        inq[u] = false;
        return;
    }
};
}  // namespace negativecycle
using namespace negativecycle;

#include <algorithm>
#include <vector>
namespace numbertheoretictransform {
using namespace std;
const int mod = 998244353, gen = 3;
inline int pow(int b, int e) {
    int ret = 1;
    while (e) {
        if (e & 1)
            ret = ((long long)ret * b) % mod;
        e >>= 1;
        b = ((long long)b * b) % mod;
    }
    return ret;
}
inline void getvec(vector<int> &r, const int &n) {
    r.clear();
    r.push_back(0);
    for (int i = 1; i < n; i++) r.push_back((r[i >> 1] >> 1) | ((i & 1) ? n >> 1 : 0));
    return;
}
inline void NTT(vector<int> &v, const int &lim, const vector<int> &r, const bool &opt = false) {
    for (int i = 0; i < lim; i++)
        if (r[i] < i)
            v[i] ^= v[r[i]] ^= v[i] ^= v[r[i]];
    int k, g, tmpg, t;
    for (int m = 2; m <= lim; m <<= 1) {
        k = m >> 1;
        g = pow(gen, (mod - 1) / m);
        for (int i = 0; i < lim; i += m) {
            tmpg = 1;
            for (int j = 0; j < k; j++) {
                t = ((long long)v[i + j + k] * tmpg) % mod;
                v[i + j + k] = ((long long)v[i + j] - t + mod) % mod;
                v[i + j] = ((long long)v[i + j] + t) % mod;
                tmpg = ((long long)tmpg * g) % mod;
            }
        }
    }
    if (opt) {
        reverse(v.begin() + 1, v.end());
        int inv = pow(lim, mod - 2);
        for (int i = 0; i < lim; i++) v[i] = ((long long)v[i] * inv) % mod;
    }
    return;
}
}  // namespace numbertheoretictransform
using namespace numbertheoretictransform;

#include <algorithm>
namespace pairingheap {
using namespace std;
template <typename T>
struct node {
    node(const T &val) : val(val) { son = p = fa = nullptr; }
    node *son, *p, *fa;
    T val;
};
template <typename T>
using PairingHeap = node<T> *;
template <typename T>
inline node<T> *Union(node<T> *a, node<T> *b) {
    if (a == nullptr)
        return b;
    if (b == nullptr)
        return a;
    if (a->val > b->val)
        swap(a, b);
    a->fa = b->fa = nullptr;
    b->p = a->son;
    if (a->son != nullptr)
        a->son->fa = b;
    a->son = b;
    return a;
}
template <typename T>
node<T> *Merge(node<T> *p) {
    if (p == nullptr || p->p == nullptr)
        return p;
    p->fa = nullptr;
    node<T> *a = p->p, *b = a->p;
    p->p = a->p = nullptr;
    a->fa = nullptr;
    return Union(Union(p, a), Merge(b));
}
template <typename T>
inline void insert(PairingHeap<T> &p, const T &val) {
    p = Union(p, new node<T>(val));
    return;
}
template <typename T>
inline T findmin(const PairingHeap<T> &p) {
    if (p == nullptr)
        return 0;
    return p->val;
}
template <typename T>
inline void deletemin(PairingHeap<T> &p) {
    p = Merge(p->son);
    return;
}
template <typename T>
inline PairingHeap<T> merge(PairingHeap<T> a, PairingHeap<T> b) {
    return Union(a, b);
}
template <typename T>
inline void decreasekey(PairingHeap<T> &p, node<T> *x, const T &val) {
    x->val -= val;
    if (x->fa == nullptr)
        return;
    if (x->fa != nullptr)
        if (x->fa->son == x)
            x->fa->son = x->p;
        else
            x->fa->p = x->p;
    if (x->p != nullptr)
        x->p->fa = x->fa;
    x->p = x->fa = nullptr;
    p = Union(p, x);
    return;
}
}  // namespace pairingheap
using namespace pairingheap;

namespace power {
using namespace std;
template <typename T>
inline T Power(T b, T e, const T &mod) {
    T ret = 1;
    while (e) {
        if (e & 1)
            ret = (ret * b) % mod;
        e >>= 1;
        b = (b * b) % mod;
    }
    return ret;
}
}  // namespace power
using namespace power;

namespace pragmas {
using namespace std;
#pragma GCC target("sse,sse2,sse3,sse4.1,sse4.2,popcnt,abm,mmx,avx")
#pragma comment(linker, "/STACK:102400000,102400000")
#pragma GCC optimize("Ofast")
#pragma GCC optimize("inline")
#pragma GCC optimize("-fgcse")
#pragma GCC optimize("-fgcse-lm")
#pragma GCC optimize("-fipa-sra")
#pragma GCC optimize("-ftree-pre")
#pragma GCC optimize("-ftree-vrp")
#pragma GCC optimize("-fpeephole2")
#pragma GCC optimize("-ffast-math")
#pragma GCC optimize("-fsched-spec")
#pragma GCC optimize("unroll-loops")
#pragma GCC optimize("-falign-jumps")
#pragma GCC optimize("-falign-loops")
#pragma GCC optimize("-falign-labels")
#pragma GCC optimize("-fdevirtualize")
#pragma GCC optimize("-fcaller-saves")
#pragma GCC optimize("-fcrossjumping")
#pragma GCC optimize("-fthread-jumps")
#pragma GCC optimize("-funroll-loops")
#pragma GCC optimize("-fwhole-program")
#pragma GCC optimize("-freorder-blocks")
#pragma GCC optimize("-fschedule-insns")
#pragma GCC optimize("inline-functions")
#pragma GCC optimize("-ftree-tail-merge")
#pragma GCC optimize("-fschedule-insns2")
#pragma GCC optimize("-fstrict-aliasing")
#pragma GCC optimize("-fstrict-overflow")
#pragma GCC optimize("-falign-functions")
#pragma GCC optimize("-fcse-skip-blocks")
#pragma GCC optimize("-fcse-follow-jumps")
#pragma GCC optimize("-fsched-interblock")
#pragma GCC optimize("-fpartial-inlining")
#pragma GCC optimize("no-stack-protector")
#pragma GCC optimize("-freorder-functions")
#pragma GCC optimize("-findirect-inlining")
#pragma GCC optimize("-fhoist-adjacent-loads")
#pragma GCC optimize("-frerun-cse-after-loop")
#pragma GCC optimize("inline-small-functions")
#pragma GCC optimize("-finline-small-functions")
#pragma GCC optimize("-ftree-switch-conversion")
#pragma GCC optimize("-foptimize-sibling-calls")
#pragma GCC optimize("-fexpensive-optimizations")
#pragma GCC optimize("-funsafe-loop-optimizations")
#pragma GCC optimize("inline-functions-called-once")
#pragma GCC optimize("-fdelete-null-pointer-checks")
}  // namespace pragmas
using namespace pragmas;

#include <climits>
#include <vector>
namespace scapegoattree {
using namespace std;
template <typename T, int maxn>
class ScapeGoatTree {
public:
    ScapeGoatTree(void) : tot(0), top(0), root(0) {}
    inline int getrank(const T &v) const {
        int p = root, rank = 1;
        while (p) {
            if (v <= val[p])
                p = ls[p];
            else
                rank += vaild[ls[p]] + !del[p], p = rs[p];
        }
        return rank;
    }
    inline T getkth(int k) const {
        if (k < 1)
            return INT_MIN;
        if (k > vaild[root])
            return INT_MAX;
        int p = root;
        while (p) {
            if (vaild[ls[p]] + 1 == k && !del[p])
                return val[p];
            if (vaild[ls[p]] >= k)
                p = ls[p];
            else
                k -= vaild[ls[p]] + !del[p], p = rs[p];
        }
        return (T)0;
    }
    void insert(const T &v) {
        int p = ins(root, 0, v);
        if (p) {
            if (p == root)
                rebuild(root);
            else {
                int father = fa[p];
                if (p == ls[father])
                    rebuild(ls[father]);
                else
                    rebuild(rs[father]);
            }
        }
        return;
    }
    inline void remove(const T &v) {
        delkth(root, getrank(v));
        if (vaild[root] < size[root] * alpha)
            rebuild(root);
        return;
    }
    inline T pre(const T &v) const { return getkth(getrank(v) - 1); }
    inline T suc(const T &v) const { return getkth(getrank(v + 1)); }

private:
    static constexpr double alpha = 0.75;
    int tot, top, root, stack[maxn];
    int ls[maxn], rs[maxn], fa[maxn];
    int vaild[maxn], size[maxn];
    bool del[maxn];
    T val[maxn];
    inline int newnode(const T &v, const int &father) {
        int p = top ? stack[top--] : ++tot;
        ls[p] = rs[p] = 0;
        del[p] = false;
        vaild[p] = size[p] = 1;
        fa[p] = father;
        val[p] = v;
        return p;
    }
    inline void maintain(const int &p) {
        vaild[p] = vaild[ls[p]] + vaild[rs[p]] + !del[p];
        size[p] = size[ls[p]] + size[rs[p]] + 1;
        return;
    }
    inline bool unbalance(const int &p) {
        return size[ls[p]] > size[p] * alpha || size[rs[p]] > size[p] * alpha;
    }
    void dfs(const int &p, vector<int> &v) {
        if (ls[p])
            dfs(ls[p], v);
        if (!del[p])
            v.push_back(p);
        else
            stack[++top] = p;
        if (rs[p])
            dfs(rs[p], v);
        return;
    }
    int build(const int &l, const int &r, const vector<int> &v) {
        if (l > r)
            return 0;
        int mid = (l + r) >> 1;
        int p = v[mid];
        ls[p] = build(l, mid - 1, v);
        rs[p] = build(mid + 1, r, v);
        fa[ls[p]] = fa[rs[p]] = p;
        maintain(p);
        return p;
    }
    inline void rebuild(int &p) {
        vector<int> v;
        int father = fa[p];
        dfs(p, v);
        p = build(0, v.size() - 1, v);
        fa[p] = father;
        return;
    }
    int ins(int &p, const int &father, const T &v) {
        if (!p) {
            p = newnode(v, father);
            return 0;
        }
        int ret;
        if (v <= val[p])
            ret = ins(ls[p], p, v);
        else
            ret = ins(rs[p], p, v);
        maintain(p);
        if (unbalance(p))
            ret = p;
        return ret;
    }
    void delkth(const int &p, const int &k) {
        vaild[p]--;
        if (!del[p] && k == vaild[ls[p]] + !del[p]) {
            del[p] = true;
            return;
        }
        if (k <= vaild[ls[p]])
            delkth(ls[p], k);
        else
            delkth(rs[p], k - vaild[ls[p]] - !del[p]);
        return;
    }
};
}  // namespace scapegoattree
using namespace scapegoattree;

#include <vector>
namespace segmenttree {
using namespace std;
template <typename T, int maxn>
class SegmentTree {
public:
    SegmentTree() : cnt(0) { root = &pool[cnt]; }
    inline void build(const vector<T> &v) {
        Build(root, 0, v.size() - 1, v);
        return;
    }
    inline void modify(const int &l, const int &r, const int &val) {
        Modify(root, l, r, val);
        return;
    }
    inline T query(const int &l, const int &r) { return Query(root, l, r); }

private:
    struct node {
        int left, right;
        T val, lazy;
        node *son[2];
    };
    node pool[maxn << 2], *root;
    int cnt;
    void Build(node *root, const int &l, const int &r, const vector<T> &v) {
        root->left = l, root->right = r;
        root->val = root->lazy = 0;
        if (l == r) {
            root->son[0] = root->son[1] = nullptr;
            root->val = v[l];
            return;
        }
        int mid = (l + r) >> 1;
        root->son[0] = &pool[++cnt];
        root->son[1] = &pool[++cnt];
        Build(root->son[0], l, mid, v);
        Build(root->son[1], mid + 1, r, v);
        root->val = root->son[0]->val + root->son[1]->val;
        return;
    }
    void Modify(node *root, const int &l, const int &r, const T &val) {
        if (root->left == l && root->right == r) {
            root->lazy += val;
            return;
        }
        push_down(root);
        if (root->son[0]->right >= r)
            Modify(root->son[0], l, r, val);
        else if (root->son[1]->left <= l)
            Modify(root->son[1], l, r, val);
        else {
            Modify(root->son[0], l, root->son[0]->right, val);
            Modify(root->son[1], root->son[1]->left, r, val);
        }
        push_down(root->son[0]);
        push_down(root->son[1]);
        push_up(root);
        return;
    }
    T Query(node *root, const int &l, const int &r) {
        push_down(root);
        if (root->left == l && root->right == r)
            return root->val;
        if (root->son[0]->right >= r)
            return Query(root->son[0], l, r);
        else if (root->son[1]->left <= l)
            return Query(root->son[1], l, r);
        return Query(root->son[0], l, root->son[0]->right) + Query(root->son[1], root->son[1]->left, r);
    }
    inline void push_up(node *p) {
        p->val = p->son[0]->val + p->son[1]->val;
        return;
    }
    inline void push_down(node *p) {
        if (!p->lazy)
            return;
        p->val += (p->right - p->left + 1) * p->lazy;
        if (p->son[0] != nullptr)
            p->son[0]->lazy += p->lazy;
        if (p->son[1] != nullptr)
            p->son[1]->lazy += p->lazy;
        p->lazy = 0;
        return;
    }
};
}  // namespace segmenttree
using namespace segmenttree;

#include <algorithm>
#include <vector>
namespace sieve {
using namespace std;
vector<bool> tisprime;
vector<int> tprimes, tphi, tmu;
inline void Sieve(const int &n, vector<bool> &isprime = tisprime, vector<int> &primes = tprimes,
                  vector<int> &phi = tphi, vector<int> &mu = tmu) {
    isprime.clear();
    isprime.resize(n + 1);
    fill(isprime.begin(), isprime.end(), true);
    primes.clear();
    phi.clear();
    phi.resize(n + 1);
    phi[1] = 1;
    mu.clear();
    mu.resize(n + 1);
    mu[1] = 1;
    for (int i = 2; i <= n; i++) {
        if (isprime[i]) {
            primes.push_back(i);
            phi[i] = i - 1;
            mu[i] = -1;
        }
        for (int j = 0; j < primes.size() && (long long)i * primes[j] <= n; j++) {
            isprime[i * primes[j]] = false;
            if (i % primes[j]) {
                phi[i * primes[j]] = phi[i] * (primes[j] - 1);
                mu[i * primes[j]] = -mu[i];
            } else {
                phi[i * primes[j]] = phi[i] * primes[j];
                mu[i * primes[j]] = 0;
                break;
            }
        }
    }
    return;
}
}  // namespace sieve
using namespace sieve;

#include <algorithm>
#include <cstring>
#include <vector>
#include <cmath>
namespace sparsetable {
using namespace std;
template <typename T, int maxn>
class SparseTable {
public:
    SparseTable(void) {
        lg[0] = -1;
        for (int i = 1; i < maxn; i++) lg[i] = lg[i >> 1] + 1;
        memset(d, 0, sizeof(d));
    }
    void preprocess(const vector<T> &A, const bool &flag = true) {
        this->flag = flag;
        n = A.size();
        for (int i = 0; i < n; i++) d[i][0] = A[i];
        for (int i = 1; (1 << i) <= n; i++)
            for (int j = 0; j + (1 << i) <= n; j++) d[j][i] = get(d[j][i - 1], d[j + (1 << (i - 1))][i - 1]);
        return;
    }
    T solve(int l, int r) {
        int k = lg[r - l + 1];
        return get(d[l][k], d[r - (1 << k) + 1][k]);
    }

private:
    T d[maxn][(int)log2(maxn) + 1];
    int lg[maxn];
    bool flag;
    int n;
    T get(T a, T b) {
        if (flag)
            return min(a, b);
        return max(a, b);
    }
};
}  // namespace sparsetable
using namespace sparsetable;

#include <cstring>
namespace superbinaryindexedtree {
using namespace std;
template <typename T, int maxn>
class SuperBinaryIndexedTree {
public:
    inline void init(const int &n) {
        this->n = n;
        t1.init(n);
        t2.init(n);
        return;
    }
    inline void add(const int &p, const T &x) {
        t1.add(p, x);
        t1.add(p + 1, -x);
        t2.add(p, (p - 1) * x);
        t2.add(p + 1, -p * x);
        return;
    }
    inline void add(const int &l, const int &r, const T &x) {
        t1.add(l, x);
        t1.add(r + 1, -x);
        t2.add(l, (l - 1) * x);
        t2.add(r + 1, -r * x);
        return;
    }
    inline T query(const int &p) const {
        return (p * t1.sum(p) - (p - 1) * t1.sum(p - 1)) - (t2.sum(p) - t2.sum(p - 1));
    }
    inline T query(const int &l, const int &r) const {
        return (r * t1.sum(r) - (l - 1) * t1.sum(l - 1)) - (t2.sum(r) - t2.sum(l - 1));
    }

private:
    class BinaryIndexedTree {
    public:
        inline void init(const int &n) {
            this->n = n;
            memset(A, 0, sizeof(A));
            memset(C, 0, sizeof(C));
            return;
        }
        inline void add(int p, const T &x) {
            while (p <= n) {
                C[p] += x;
                p += lowbit(p);
            }
            return;
        }
        inline T sum(int num) const {
            T ret = 0;
            while (num) {
                ret += C[num];
                num -= lowbit(num);
            }
            return ret;
        }

    private:
        T A[maxn], C[maxn];
        int n;
        inline int lowbit(const int &num) const { return num & (-num); }
    };
    BinaryIndexedTree t1, t2;
    int n;
};
}  // namespace superbinaryindexedtree
using namespace superbinaryindexedtree;

#include <cstring>
#include <stack>
namespace tarjan {
using namespace std;
template <int maxn>
class Tarjan {
public:
    Tarjan(void) { init(); }
    inline void init(void) {
        memset(G, 0, sizeof(G));
        memset(head, 0, sizeof(head));
        cnt = 0;
        return;
    }
    inline void AddEdge(const int &u, const int &v) {
        G[++cnt].to = v;
        G[cnt].nxt = head[u];
        head[u] = cnt;
        return;
    }
    int sccno[maxn], sccnum[maxn], scc_cnt;
    inline void tarjan(int n) {
        dfs_clock = scc_cnt = 0;
        memset(sccno, 0, sizeof(sccno));
        memset(pre, 0, sizeof(pre));
        for (int i = 1; i <= n; i++)
            if (!pre[i])
                dfs(i);
        return;
    }
    struct edge {
        int to, nxt;
    };
    edge G[maxn];
    int head[maxn], cnt;

private:
    stack<int> s;
    int dfs_clock;
    int pre[maxn], lowlink[maxn];
    void dfs(int u) {
        pre[u] = lowlink[u] = ++dfs_clock;
        s.push(u);
        for (int i = head[u]; i; i = G[i].nxt) {
            int v = G[i].to;
            if (!pre[v]) {
                dfs(v);
                lowlink[u] = min(lowlink[u], lowlink[v]);
            } else if (!sccno[v])
                lowlink[u] = min(lowlink[u], pre[v]);
        }
        if (lowlink[u] == pre[u]) {
            scc_cnt++;
            int v;
            do {
                v = s.top();
                s.pop();
                sccnum[scc_cnt]++;
                sccno[v] = scc_cnt;
            } while (u != v);
        }
        return;
    }
};
}  // namespace tarjan
using namespace tarjan;

namespace tonellishanks {
using namespace std;
template <typename T>
inline T Power(T b, T e, const T &mod) {
    T ret = 1;
    while (e) {
        if (e & 1)
            ret = (ret * b) % mod;
        e >>= 1;
        b = (b * b) % mod;
    }
    return ret;
}
template <typename T>
inline bool EulersCriterion(const T &a, const T &p) {
    return Power(a, p >> 1, p) == 1;
}
template <typename T>
inline T TonelliShanks(const T &n, const T &p) {
    if (!EulersCriterion(n, p))
        return -1;
    T Q = p - 1, S = 0, z = 2;
    while (!(Q & 1)) Q >>= 1, S++;
    while (EulersCriterion(z, p)) z++;
    T M = S, c = Power(z, Q, p), t = pow(n, Q, p), R = pow(n, (Q + 1) >> 1);
    T i, tmp, b;
    while (t > 1) {
        i = 0, tmp = t;
        while (tmp != 1) tmp = (tmp * tmp) % p, i++;
        b = Power(c, Power(2, M - i - 1, p), p);
        M = i, c = (b * b) % p, t = (t * c) % p, R = (R * b) % p;
    }
    return t ? R : 0;
}
}  // namespace tonellishanks
using namespace tonellishanks;

#include <cstring>
#include <random>
#include <ctime>
namespace treap {
using namespace std;
mt19937 rand(time(nullptr));
template <typename T>
struct Node {
    Node *son[2];
    int r, s;
    T v;
    Node(const T &data) { son[0] = son[1] = nullptr, v = data, r = rand(), s = 1; }
    inline void maintain(void) {
        s = 1;
        if (son[0] != nullptr)
            s += son[0]->s;
        if (son[1] != nullptr)
            s += son[1]->s;
        return;
    }
};
template <typename T>
using Treap = Node<T> *;
template <typename T>
using Pair = pair<Node<T> *, Node<T> *>;
template <typename T>
inline int size(Node<T> *t) {
    return t == nullptr ? 0 : t->s;
}
template <typename T>
Pair<T> spilt(Node<T> *t, const int &p) {
    if (t == nullptr)
        return Pair<T>(nullptr, nullptr);
    Pair<T> ret;
    if (size(t->son[0]) >= p) {
        ret = spilt(t->son[0], p);
        t->son[0] = ret.second;
        t->maintain();
        ret.second = t;
    } else {
        ret = spilt(t->son[1], p - size(t->son[0]) - 1);
        t->son[1] = ret.first;
        t->maintain();
        ret.first = t;
    }
    return ret;
}
template <typename T>
Node<T> *merge(Node<T> *a, Node<T> *b) {
    if (a == nullptr)
        return b;
    if (b == nullptr)
        return a;
    if (a->r < b->r) {
        a->son[1] = merge(a->son[1], b);
        a->maintain();
        return a;
    }
    b->son[0] = merge(a, b->son[0]);
    b->maintain();
    return b;
}
template <typename T>
inline int getrank(Treap<T> t, const T &val) {
    Node<T> *p = t;
    int rank = 0;
    while (p != nullptr) {
        if (val <= p->v)
            p = p->son[0];
        else {
            rank += (size(p->son[0]) + 1);
            p = p->son[1];
        }
    }
    return rank;
}
template <typename T>
inline T getkth(Treap<T> t, const int &k) {
    Pair<T> x = spilt(t, k - 1);
    Pair<T> y = spilt(x.second, 1);
    Treap<T> tmp = y.first;
    t = merge(x.first, merge(tmp, y.second));
    return tmp == nullptr ? (T)0 : tmp->v;
}
template <typename T>
inline void insert(Treap<T> &t, const T &val) {
    int rank = getrank(t, val);
    Pair<T> x = spilt(t, rank);
    Treap<T> tmp = new Node<T>(val);
    t = merge(x.first, merge(tmp, x.second));
    return;
}
template <typename T>
inline void remove(Treap<T> &t, const T &val) {
    int rank = getrank(t, val);
    Pair<T> x = spilt(t, rank);
    Pair<T> y = spilt(x.second, 1);
    t = merge(x.first, y.second);
    return;
}
template <typename T>
inline bool find(const Treap<T> &t, const T &val) {
    Node<T> *p = t;
    while (p != nullptr) {
        if (p->v == val)
            return true;
        if (p->v > val)
            p = p->son[0];
        else
            p = p->son[1];
    }
    return false;
}
template <typename T>
inline T pre(Treap<T> &t, const T &val) {
    return getkth(t, getrank(t, val));
}
template <typename T>
inline T nxt(Treap<T> &t, const T &val) {
    return getkth(t, getrank(t, val + 1) + 1);
}
template <typename T>
io::ostream &operator<<(io::ostream &out, const Treap<T> &t) {
    if (t == nullptr)
        return out;
    out << t->son[0] << t->v << ' ' << t->son[1];
    return out;
}
using TreapInt = Treap<int>;
using TreapLongLong = Treap<long long>;
}  // namespace treap
using namespace treap;

#include <cstring>
#include <vector>
namespace trie {
using namespace std;
template <int maxn, int sigmasize>
class Trie {
public:
    Trie() { clear(); }
    inline void clear(void) {
        cnt = 1;
        memset(ch[0], 0, sizeof(ch[0]));
        memset(val, 0, sizeof(val));
        return;
    }
    inline bool insert(const vector<int> &v, const int &num = 1) {
        int len = v.size(), u = 0;
        bool f = false;
        for (int i = 0; i < len; i++) {
            if (!ch[u][v[i]]) {
                memset(ch[cnt], 0, sizeof(ch[cnt]));
                val[cnt] = 0;
                ch[u][v[i]] = cnt++;
            } else if (i + 1 == len)
                f = true;
            u = ch[u][v[i]];
            if (val[u])
                f = true;
        }
        val[u] = num;
        return f;
    }
    inline bool find(const vector<int> &v) const {
        int len = v.size(), u = 0;
        for (int i = 0; i < len; i++) {
            if (!ch[u][v[i]])
                return false;
            u = ch[u][v[i]];
        }
        return true;
    }

private:
    int ch[maxn][sigmasize];
    int val[maxn], cnt;
};
}  // namespace trie
using namespace trie;

#include <cstring>
#include <vector>
#include <stack>
namespace twosat {
using namespace std;
template <int maxn>
class TwoSat {
public:
    TwoSat(void) { init(); }
    inline void init() {
        t.init();
        return;
    }
    inline void AddClause(const int &x, const int &xval, const int &y, const int &yval) {
        t.AddEdge((x << 1) + (xval & 1), (y << 1) + (yval ^ 1));
        t.AddEdge((y << 1) + (yval & 1), (x << 1) + (xval ^ 1));
        return;
    }
    inline bool solve(const int &n, vector<bool> &ans = v) {
        t.tarjan(n << 1);
        ans.clear();
        for (int i = 0; i <= n; i++)
            if (t.sccno[i << 1] == t.sccno[i << 1 | 1])
                return false;
        for (int i = 0; i <= n; i++) ans.push_back(t.sccno[i << 1] < t.sccno[i << 1 | 1]);
        return true;
    }

private:
    static vector<bool> v;
    class Tarjan {
    public:
        Tarjan(void) { init(); }
        inline void init(void) {
            memset(G, 0, sizeof(G));
            memset(head, 0, sizeof(head));
            cnt = 0;
            return;
        }
        inline void AddEdge(const int &u, const int &v) {
            G[++cnt].to = v;
            G[cnt].nxt = head[u];
            head[u] = cnt;
            return;
        }
        int sccno[maxn << 1], sccnum[maxn << 1], scc_cnt;
        inline void tarjan(int n) {
            dfs_clock = scc_cnt = 0;
            memset(sccno, 0, sizeof(sccno));
            memset(pre, 0, sizeof(pre));
            for (int i = 1; i <= n; i++)
                if (!pre[i])
                    dfs(i);
            return;
        }
        struct edge {
            int to, nxt;
        };
        edge G[maxn << 1];
        int head[maxn << 1], cnt;

    private:
        stack<int> s;
        int dfs_clock;
        int pre[maxn << 1], lowlink[maxn << 1];
        void dfs(int u) {
            pre[u] = lowlink[u] = ++dfs_clock;
            s.push(u);
            for (int i = head[u]; i; i = G[i].nxt) {
                int v = G[i].to;
                if (!pre[v]) {
                    dfs(v);
                    lowlink[u] = min(lowlink[u], lowlink[v]);
                } else if (!sccno[v])
                    lowlink[u] = min(lowlink[u], pre[v]);
            }
            if (lowlink[u] == pre[u]) {
                scc_cnt++;
                int v;
                do {
                    v = s.top();
                    s.pop();
                    sccnum[scc_cnt]++;
                    sccno[v] = scc_cnt;
                } while (u != v);
            }
            return;
        }
    };
    Tarjan t;
};
}  // namespace twosat
using namespace twosat;

#include <cstring>
namespace unionfindset {
using namespace std;
template <int maxn>
class UnionFindSet {
public:
    inline void init(const int &n) {
        memset(fa, 0, sizeof(fa));
        for (int i = 1; i <= n; i++) fa[i] = i;
        memset(rank, 0, sizeof(rank));
        return;
    }
    inline void Union(const int &u, const int &v) {
        int x = find(u), y = find(v);
        if (rank[x] < rank[y])
            fa[x] = y;
        else {
            fa[y] = x;
            if (rank[x] == rank[y])
                rank[x]++;
        }
        return;
    }
    inline bool Find(const int &u, const int &v) { return this->find(u) == this->find(v); }
    int fa[maxn];

private:
    int find(const int &u) { return fa[u] == u ? u : fa[u] = find(fa[u]); }
    int rank[maxn];
};
}  // namespace unionfindset
using namespace unionfindset;

#include <cstring>
#include <deque>
namespace zeroonebfs {
using namespace std;
template <int maxn>
class ZeroOneBfs {
public:
    ZeroOneBfs(void) { init(); }
    inline void init(void) {
        memset(G, 0, sizeof(G));
        memset(head, 0, sizeof(head));
        cnt = 0;
        return;
    }
    inline void AddEdge(const int &u, const int &v, const int &f) {
        G[++cnt].to = v;
        G[cnt].nxt = head[u];
        G[cnt].val = f;
        head[u] = cnt;
        return;
    }
    int d[maxn];
    inline void solve(const int &v, const int &s = 1) {
        memset(d, 0x3f, sizeof(d));
        deque<int> Q;
        while (!Q.empty()) Q.pop_front();
        Q.push_back(s);
        d[s] = 0;
        int u;
        while (!Q.empty()) {
            u = Q.front();
            Q.pop_front();
            for (int i = head[u]; i; i = G[i].nxt)
                if (d[G[i].to] > d[u] + (int)(G[i].val > v)) {
                    d[G[i].to] = d[u] + (int)(G[i].val > v);
                    if (G[i].val > v)
                        Q.push_back(G[i].to);
                    else
                        Q.push_front(G[i].to);
                }
        }
        return;
    }

private:
    struct edge {
        int to, nxt, val;
    };
    edge G[maxn];
    int head[maxn], cnt;
};
}  // namespace zeroonebfs
using namespace zeroonebfs;
