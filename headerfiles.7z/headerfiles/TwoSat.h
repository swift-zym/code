#pragma once

#include <cstring>
#include <vector>
#include <stack>
namespace twosat {
using namespace std;
#define fastcall __attribute__((optimize("-O3")))
#define IL __inline__ __attribute__((always_inline))
template <int maxn>
class TwoSat {
public:
    TwoSat(void) { init(); }
    fastcall IL void init() {
        t.init();
        return;
    }
    fastcall IL void AddClause(const int &x, const int &xval, const int &y, const int &yval) {
        t.AddEdge((x << 1) + (xval & 1), (y << 1) + (yval ^ 1));
        t.AddEdge((y << 1) + (yval & 1), (x << 1) + (xval ^ 1));
        return;
    }
    fastcall IL bool solve(const int &n, vector<bool> &ans = v) {
        t.tarjan(n << 1);
        ans.clear();
        for (int i = 0; i <= n; i++)
            if (t.sccno[i << 1] == t.sccno[i << 1 | 1])
                return false;
        for (int i = 0; i <= n; i++) ans.push_back(t.sccno[i << 1] < t.sccno[i << 1 | 1]);
        return true;
    }

private:
    static vector<bool> v;
    class Tarjan {
    public:
        Tarjan(void) { init(); }
        fastcall IL void init(void) {
            memset(G, 0, sizeof(G));
            memset(head, 0, sizeof(head));
            cnt = 0;
            return;
        }
        fastcall IL void AddEdge(const int &u, const int &v) {
            G[++cnt].to = v;
            G[cnt].nxt = head[u];
            head[u] = cnt;
            return;
        }
        int sccno[maxn << 1], sccnum[maxn << 1], scc_cnt;
        fastcall IL void tarjan(int n) {
            dfs_clock = scc_cnt = 0;
            memset(sccno, 0, sizeof(sccno));
            memset(pre, 0, sizeof(pre));
            for (int i = 1; i <= n; i++)
                if (!pre[i])
                    dfs(i);
            return;
        }
        struct edge {
            int to, nxt;
        };
        edge G[maxn << 1];
        int head[maxn << 1], cnt;

    private:
        stack<int> s;
        int dfs_clock;
        int pre[maxn << 1], lowlink[maxn << 1];
        fastcall void dfs(int u) {
            pre[u] = lowlink[u] = ++dfs_clock;
            s.push(u);
            for (int i = head[u]; i; i = G[i].nxt) {
                int v = G[i].to;
                if (!pre[v]) {
                    dfs(v);
                    lowlink[u] = min(lowlink[u], lowlink[v]);
                } else if (!sccno[v])
                    lowlink[u] = min(lowlink[u], pre[v]);
            }
            if (lowlink[u] == pre[u]) {
                scc_cnt++;
                int v;
                do {
                    v = s.top();
                    s.pop();
                    sccnum[scc_cnt]++;
                    sccno[v] = scc_cnt;
                } while (u != v);
            }
            return;
        }
    };
    Tarjan t;
};
}  // namespace twosat
using namespace twosat;
