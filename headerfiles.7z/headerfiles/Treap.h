#pragma once

#include "IO.h"
#include <cstring>
#include <random>
#include <ctime>
namespace treap {
using namespace std;
#define fastcall __attribute__((optimize("-O3")))
#define IL __inline__ __attribute__((always_inline))
mt19937 rand(time(nullptr));
template <typename T>
struct Node {
    Node *son[2];
    int r, s;
    T v;
    Node(const T &data) { son[0] = son[1] = nullptr, v = data, r = rand(), s = 1; }
    fastcall IL void maintain(void) {
        s = 1;
        if (son[0] != nullptr)
            s += son[0]->s;
        if (son[1] != nullptr)
            s += son[1]->s;
        return;
    }
};
template <typename T>
using Treap = Node<T> *;
template <typename T>
using Pair = pair<Node<T> *, Node<T> *>;
template <typename T>
fastcall IL int size(Node<T> *t) {
    return t == nullptr ? 0 : t->s;
}
template <typename T>
fastcall Pair<T> spilt(Node<T> *t, const int &p) {
    if (t == nullptr)
        return Pair<T>(nullptr, nullptr);
    Pair<T> ret;
    if (size(t->son[0]) >= p) {
        ret = spilt(t->son[0], p);
        t->son[0] = ret.second;
        t->maintain();
        ret.second = t;
    } else {
        ret = spilt(t->son[1], p - size(t->son[0]) - 1);
        t->son[1] = ret.first;
        t->maintain();
        ret.first = t;
    }
    return ret;
}
template <typename T>
fastcall Node<T> *merge(Node<T> *a, Node<T> *b) {
    if (a == nullptr)
        return b;
    if (b == nullptr)
        return a;
    if (a->r < b->r) {
        a->son[1] = merge(a->son[1], b);
        a->maintain();
        return a;
    }
    b->son[0] = merge(a, b->son[0]);
    b->maintain();
    return b;
}
template <typename T>
fastcall IL int getrank(Treap<T> t, const T &val) {
    Node<T> *p = t;
    int rank = 0;
    while (p != nullptr) {
        if (val <= p->v)
            p = p->son[0];
        else {
            rank += (size(p->son[0]) + 1);
            p = p->son[1];
        }
    }
    return rank;
}
template <typename T>
fastcall IL T getkth(Treap<T> t, const int &k) {
    Pair<T> x = spilt(t, k - 1);
    Pair<T> y = spilt(x.second, 1);
    Treap<T> tmp = y.first;
    t = merge(x.first, merge(tmp, y.second));
    return tmp == nullptr ? (T)0 : tmp->v;
}
template <typename T>
fastcall IL void insert(Treap<T> &t, const T &val) {
    int rank = getrank(t, val);
    Pair<T> x = spilt(t, rank);
    Treap<T> tmp = new Node<T>(val);
    t = merge(x.first, merge(tmp, x.second));
    return;
}
template <typename T>
fastcall IL void remove(Treap<T> &t, const T &val) {
    int rank = getrank(t, val);
    Pair<T> x = spilt(t, rank);
    Pair<T> y = spilt(x.second, 1);
    t = merge(x.first, y.second);
    return;
}
template <typename T>
fastcall IL bool find(const Treap<T> &t, const T &val) {
    Node<T> *p = t;
    while (p != nullptr) {
        if (p->v == val)
            return true;
        if (p->v > val)
            p = p->son[0];
        else
            p = p->son[1];
    }
    return false;
}
template <typename T>
fastcall IL T pre(Treap<T> &t, const T &val) {
    return getkth(t, getrank(t, val));
}
template <typename T>
fastcall IL T nxt(Treap<T> &t, const T &val) {
    return getkth(t, getrank(t, val + 1) + 1);
}
template <typename T>
io::ostream &operator<<(io::ostream &out, const Treap<T> &t) {
    if (t == nullptr)
        return out;
    out << t->son[0] << t->v << ' ' << t->son[1];
    return out;
}
using TreapInt = Treap<int>;
using TreapLongLong = Treap<long long>;
}  // namespace treap
using namespace treap;
