#pragma once

#include <random>
#include <ctime>
#include <cmath>
namespace millerrabin {
using namespace std;
template <typename T>
T Power(T b, T e, const T &mod) {
    T ret = 1;
    while (e) {
        if (e & 1)
            ret = (ret * b) % mod;
        e >>= 1;
        b = (b * b) % mod;
    }
    return ret;
}
template <typename T>
inline T multyply(T x, T y, const T &mod) {
    x %= mod, y %= mod;
    return ((x * y - (T)(((long double)x * y + 0.5) / mod) * mod) % mod + mod) % mod;
}
template <typename T>
inline bool MillerRabin(const T &n, const T &a) {
    T t = 0, u = n, x;
    while (!(u & 1)) u >>= 1, t++;
    x = Power(a, u, n);
    if (x == 1 || x + 1 == n)
        return true;
    while (t--) {
        x = multyply(x, x, n);
        if (x + 1 == n)
            return true;
    }
    return false;
}
template <typename T>
inline bool check(const T &n, int cnt = 10) {
    const T t = ceil(log2(n));
    for (int i = 2; i <= t; i++)
        if (!(n % i))
            return false;
    T a;
    mt19937_64 rand(time(nullptr));
    while (cnt--) {
        a = rand() % (n - 2) + 1;
        if (!MillerRabin(n, a))
            return false;
    }
    return true;
}
}  // namespace millerrabin
using namespace millerrabin;
