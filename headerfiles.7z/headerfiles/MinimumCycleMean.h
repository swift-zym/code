#pragma once

#include <algorithm>
#include <cstring>
#include <cfloat>
namespace minimumcyclemean {
using namespace std;
#define fastcall __attribute__((optimize("-O3")))
#define IL __inline__ __attribute__((always_inline))
template <typename T, int maxn>
class MinimumCycleMean {
public:
    MinimumCycleMean(void) { init(); }
    fastcall IL void init(void) {
        memset(G, 0, sizeof(G));
        cnt = 0;
        return;
    }
    fastcall IL void AddEdge(const int &u, const int &v, const T &val) {
        G[++cnt].from = u;
        G[cnt].to = v;
        G[cnt].val = val;
        return;
    }
    fastcall IL double minimumcyclemean(const int &n) {
        memset(F, 0, sizeof(F));
        int cur = 0;
        for (int i = 1; i <= n; i++) {
            fill(F[cur] + 1, F[cur] + n + 1, DBL_MAX);
            for (int j = 1; j <= cnt; j++)
                F[cur][G[j].to] = min(F[cur][G[j].to], F[cur ^ 1][G[j].from] + G[j].val);
            cur ^= 1;
        }
        memcpy(F[2], F[cur ^ 1], sizeof(F[cur ^ 1]));
        memset(F[cur ^ 1], 0, sizeof(F[cur ^ 1]));
        memset(maxv, 0, sizeof(maxv));
        for (int i = 1; i <= n; i++) maxv[i] = F[2][i] / n;
        for (int i = 1; i <= n; i++) {
            fill(F[cur] + 1, F[cur] + n + 1, DBL_MAX);
            for (int j = 1; j <= cnt; j++)
                F[cur][G[j].to] = min(F[cur][G[j].to], F[cur ^ 1][G[j].from] + G[j].val);
            for (int j = 1; j <= n; j++) maxv[j] = max(maxv[j], (F[2][j] - F[cur][j]) / (n - i));
            cur ^= 1;
        }
        double ret = DBL_MAX;
        for (int i = 1; i <= n; i++) ret = min(ret, maxv[i]);
        return ret;
    }
    struct edge {
        int from, to;
        T val;
    };
    edge G[maxn];
    int cnt;

private:
    double F[3][maxn], maxv[maxn];
};
}  // namespace minimumcyclemean
using namespace minimumcyclemean;
