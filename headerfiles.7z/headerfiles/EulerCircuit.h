#pragma once

#include <cstring>
#include <queue>
namespace eulercircuit {
using namespace std;
#define fastcall __attribute__((optimize("-O3")))
#define IL __inline__ __attribute__((always_inline))
template <int maxn>
class EulerCircuit {
public:
    EulerCircuit(void) { init(); }
    fastcall IL void init(const int &n = 0, const bool &f = false) {
        this->n = n;
        directed = f;
        memset(G, 0, sizeof(G));
        memset(deg, 0, sizeof(deg));
        memset(head, 0, sizeof(head));
        memset(this->f, 0, sizeof(this->f));
        cnt = 0;
        return;
    }
    fastcall IL void AddEdge(const int &u, const int &v) {
        G[++cnt].to = v;
        G[cnt].nxt = head[u];
        head[u] = cnt;
        deg[0][u]++, deg[1][v]++;
        f[u] = f[v] = true;
        return;
    }
    int ans[maxn], c;
    fastcall IL bool eulercircuit(void) {
        memset(stack, 0, sizeof(stack));
        memset(vis, 0, sizeof(vis));
        memset(tmp, 0, sizeof(tmp));
        if (directed) {
            for (int i = 1; i <= n; i++)
                if (deg[0][i] != deg[1][i])
                    return false;
        } else {
            for (int i = 1; i <= n; i++)
                if ((deg[0][i] & 1) || (deg[1][i] & 1))
                    return false;
        }
        tot = c = 0;
        for (int i = 1; i <= n; i++)
            if (f[i]) {
                stack[++tot] = i;
                break;
            }
        bool flag;
        int v = !directed, val = 0;
        while (tot) {
            flag = false;
            for (int i = head[stack[tot]]; i; i = G[i].nxt)
                if (!vis[((i - 1) >> v) + 1]) {
                    val++;
                    head[stack[tot]] = G[i].nxt;
                    flag = true;
                    vis[((i - 1) >> v) + 1] = 1;
                    stack[++tot] = G[i].to;
                    tmp[tot] = i;
                    if (v) {
                        tmp[tot] = ((i - 1) >> 1) + 1;
                        if (!(i & 1))
                            tmp[tot] = 1 + ~tmp[tot];
                    }
                    break;
                }
            if (!flag) {
                if (tot != 1)
                    ans[++c] = tmp[tot];
                tot--;
            }
        }
        for (int p = 1; (p << 1) <= c; p++) ans[p] ^= ans[c - p + 1] ^= ans[p] ^= ans[c - p + 1];
        return val == cnt >> v;
    }
    struct edge {
        int to, nxt;
    };
    edge G[maxn];
    int head[maxn], cnt;
    bool directed;
    int n;

private:
    bool vis[maxn], f[maxn];
    int stack[maxn], tot;
    int deg[2][maxn];
    int tmp[maxn];
};
}  // namespace eulercircuit
using namespace eulercircuit;
