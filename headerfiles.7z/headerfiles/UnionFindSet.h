#pragma once

#include <cstring>
namespace unionfindset {
using namespace std;
#define fastcall __attribute__((optimize("-O3")))
#define IL __inline__ __attribute__((always_inline))
template <int maxn>
class UnionFindSet {
public:
    fastcall IL void init(const int &n) {
        memset(fa, 0, sizeof(fa));
        for (int i = 1; i <= n; i++) fa[i] = i;
        memset(rank, 0, sizeof(rank));
        return;
    }
    fastcall IL void Union(const int &u, const int &v) {
        int x = find(u), y = find(v);
        if (rank[x] < rank[y])
            fa[x] = y;
        else {
            fa[y] = x;
            if (rank[x] == rank[y])
                rank[x]++;
        }
        return;
    }
    fastcall IL bool Find(const int &u, const int &v) { return this->find(u) == this->find(v); }
    int fa[maxn];

private:
    fastcall int find(const int &u) { return fa[u] == u ? u : fa[u] = find(fa[u]); }
    int rank[maxn];
};
}  // namespace unionfindset
using namespace unionfindset;
