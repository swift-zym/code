#pragma once

#include <cstring>
namespace suffixarrayinducesort {
using namespace std;
#define fastcall __attribute__((optimize("-O3")))
#define IL __inline__ __attribute__((always_inline))
template <int maxn>
fastcall void sais(const int &n, int *a, int *sa) {
    int *pointer = new int[maxn << 3];
    int *p1, *p2, *rk, *sum, *cur, *a1;
    p1 = pointer, pointer += n + 1;
    p2 = pointer, pointer += n + 2;
    rk = pointer, pointer += n + 1;
    sum = pointer, pointer += n + 1;
    cur = pointer, pointer += n + 1;
    p1[n] = 1;
    for (int i = n - 1; i >= 0; i--) p1[i] = (a[i] == a[i + 1] ? p1[i + 1] : (a[i] < a[i + 1]));
    int m = 0;
    for (int i = 1; i <= n; i++) rk[i] = ((p1[i] && !p1[i - 1]) ? (p2[++m] = i, m) : -1);
    {
        for (int i = 1; i <= n; i++) sa[i] = -1;
        for (int i = 1; i <= n; i++) sum[i] = 0;
        for (int i = 1; i <= n; i++) sum[a[i]]++;
        for (int i = 1; i <= n; i++) sum[i] += sum[i - 1];
        for (int i = 1; i <= n; i++) cur[i] = sum[i];
        for (int i = m; i > 0; i--) sa[cur[a[p2[i]]]--] = p2[i];
        for (int i = 1; i <= n; i++) cur[i] = sum[i - 1] + 1;
        for (int i = 1; i <= n; i++)
            if (sa[i] > 1 && !p1[sa[i] - 1])
                sa[cur[a[sa[i] - 1]]++] = sa[i] - 1;
        for (int i = 1; i <= n; i++) cur[i] = sum[i];
        for (int i = n; i > 0; i--)
            if (sa[i] > 1 && p1[sa[i] - 1])
                sa[cur[a[sa[i] - 1]]--] = sa[i] - 1;
    }
    int tot = 0;
    a1 = pointer, pointer += m + 1;
    p2[m + 1] = n;
    int x, y;
    for (int i = 1; i <= n; i++) {
        x = rk[sa[i]];
        if (x != -1) {
            if (!tot || p2[x + 1] - p2[x] != p2[y + 1] - p2[y])
                tot++;
            else
                for (int k1 = p2[x], k2 = p2[y]; k2 <= p2[y + 1]; k1++, k2++)
                    if ((a[k1] << 1 | p1[k1]) != (a[k2] << 1 | p1[k2])) {
                        tot++;
                        break;
                    }
            a1[x] = tot;
            y = x;
        }
    }
    if (tot == m)
        for (int i = 1; i <= m; i++) sa[a1[i]] = i;
    else
        sais(m, a1);
    for (int i = 1; i <= m; i++) a1[i] = p[sa[i]];
    for (int i = 1; i <= n; i++) sa[i] = -1;
    for (int i = 1; i <= n; i++) sum[i] = 0;
    for (int i = 1; i <= n; i++) sum[a[i]]++;
    for (int i = 1; i <= n; i++) sum[i] += sum[i - 1];
    for (int i = 1; i <= n; i++) cur[i] = sum[i];
    for (int i = m; i > 0; i--) sa[cur[a[a1[i]]]--] = a1[i];
    for (int i = 1; i <= n; i++) cur[i] = sum[i - 1] + 1;
    for (int i = 1; i <= n; i++)
        if (sa[i] > 1 && !p1[sa[i] - 1])
            sa[cur[a[sa[i] - 1]]++] = sa[i] - 1;
    for (int i = 1; i <= n; i++) cur[i] = sum[i];
    for (int i = n; i > 0; i--)
        if (sa[i] > 1 && p1[sa[i] - 1])
            sa[cur[a[sa[i] - 1]]--] = sa[i] - 1;
    delete[] pointer;
    return;
}
template <int maxn>
fastcall IL void SuffixArrayInduceSort(char *str, int *&sa) {
    static int maxv = 300;
    int t[maxv], len = strlen(str + 1) - 1;
    memset(t, 0, sizeof(t));
    for (int i = 1; i <= len; i++) t[str[i]] = 1;
    for (int i = 1; i < maxv; i++) t[i] += t[i - 1];
    int a[maxn];
    memset(a, 0, sizeof(a));
    for (int i = 1; i <= len; i++) a[i] = t[str[i]] + 1;
    a[++len] = 1;
    sa = new int[maxn + 10];
    sais<maxn>(len, a, sa);
    return;
}
}  // namespace suffixarrayinducesort
using namespace suffixarrayinducesort;
