#pragma once

#include <algorithm>
#include <vector>
namespace selection {
using namespace std;
#define fastcall __attribute__((optimize("-O3")))
#define IL __inline__ __attribute__((always_inline))
template <typename T>
fastcall int BFPRT(vector<T> a, const int &l, const int &r, const int &k) {
    int n = r - l;
    if (n < 5) {
        sort(a.begin() + l, a.begin() + r);
        return a[l + k - 1];
    }
    for (int i = 0; i < n / 5; i++) {
        sort(a.begin() + l + i * 5, a.begin() + l + i * 5 + 5);
        swap(a[l + i], a[l + i * 5 + 2]);
    }
    int x = BFPRT(a, l, l + n / 5, n / 10 + 1);
    int low = l, high = r;
    int i = low;
    high--;
    while (a[i] != x) i++;
    swap(a[low], a[i]);
    while (low < high) {
        while (low < high && a[high] >= x) high--;
        a[low] = a[high];
        while (low < high && a[low] <= x) low++;
        a[high] = a[low];
    }
    a[low] = x;
    int q = low - l + 1;
    if (q == k)
        return x;
    if (q > k)
        return BFPRT(a, l, low + 1, k);
    return BFPRT(a, low + 1, r, k - q);
}
template <typename T>
fastcall IL int Selection(const vector<T> &a, const int &k) {
    return BFPRT(a, 0, a.size() - 1, k);
}
}  // namespace selection
using namespace selection;
