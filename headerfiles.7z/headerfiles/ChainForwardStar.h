#pragma once

#include <cstring>
namespace chainforwardstar {
using namespace std;
template <typename T, int maxn>
class ChainForwardStar {
public:
    ChainForwardStar(void) { init(); }
    void init(void) {
        memset(G, 0, sizeof(G));
        memset(head, 0, sizeof(head));
        cnt = 0;
        return;
    }
    void AddEdge(const int &u, const int &v, const T &val) {
        G[++cnt].from = u;
        G[++cnt].to = v;
        G[head[u]].front = cnt;
        G[cnt].nxt = head[u];
        G[cnt].val = val;
        head[u] = cnt;
        return;
    }
    void DeleteEdge(const int &p) {
        int a = G[p].front, b = G[p].nxt;
        if (!a)
            head[G[p].from] = b;
        else
            G[a].nxt = b;
        if (b)
            G[b].front = a;
        return;
    }
    struct edge {
        int from, to, front, nxt;
        T val;
    };
    edge G[maxn];
    int head[maxn], cnt;
};
}  // namespace chainforwardstar
using namespace chainforwardstar;
