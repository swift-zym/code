#pragma once

#include <climits>
#include <cstring>
#include <queue>
namespace hopcroftkarp {
using namespace std;
template <int maxn>
class HopcroftKarp {
public:
    HopcroftKarp() { init(); }
    inline void init(void) {
        memset(G, 0, sizeof(G));
        memset(head, 0, sizeof(head));
        cnt = 0;
        return;
    }
    inline void AddEdge(const int &u, const int &v) {
        G[++cnt].to = v;
        G[cnt].nxt = head[u];
        head[u] = cnt;
        return;
        return;
    }
    int pair_l[maxn], pair_r[maxn], n, m;
    inline int solve(const int &n, const int &m) {
        this->n = n, this->m = m;
        memset(pair_l, -1, sizeof(pair_l));
        memset(pair_r, -1, sizeof(pair_r));
        int c = 0;
        while (bfs())
            for (int u = 1; u <= n; u++)
                if (pair_l[u] == -1)
                    c += dfs(u);
        return c;
    }

private:
    struct edge {
        int to, nxt;
    };
    int cnt;
    edge G[maxn << 1];
    int head[maxn];
    bool vis[maxn];
    int dist[2][maxn], d;
    inline bool bfs(void) {
        memset(vis, 0, sizeof(vis));
        memset(dist, -1, sizeof(dist));
        static queue<int> Q;
        d = INT_MAX;
        for (int i = 1; i <= n; i++)
            if (pair_l[i] == -1)
                dist[0][i] = 0, Q.push(i);
        while (!Q.empty()) {
            int u = Q.front();
            Q.pop();
            if (dist[0][u] <= d)
                for (int i = head[u]; i; i = G[i].nxt)
                    if (dist[1][G[i].to] == -1) {
                        dist[1][G[i].to] = dist[0][u] + 1;
                        if (pair_r[G[i].to] == -1)
                            d = dist[1][G[i].to];
                        else
                            dist[0][pair_r[G[i].to]] = dist[1][G[i].to] + 1, Q.push(pair_r[G[i].to]);
                    }
        }
        return d != INT_MAX;
    }
    bool dfs(const int &u) {
        for (int i = head[u]; i; i = G[i].nxt)
            if (!vis[G[i].to] && dist[1][G[i].to] == dist[0][u] + 1) {
                vis[G[i].to] = true;
                if (pair_r[G[i].to] != -1 && dist[1][G[i].to] == d)
                    continue;
                if (pair_r[G[i].to] == -1 || dfs(pair_r[G[i].to])) {
                    pair_l[u] = G[i].to;
                    pair_r[G[i].to] = u;
                    return true;
                }
            }
        return false;
    }
};
}  // namespace hopcroftkarp
using namespace hopcroftkarp;
