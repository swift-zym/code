#pragma once

#include <cstring>
namespace superbinaryindexedtree {
using namespace std;
#define fastcall __attribute__((optimize("-O3")))
#define IL __inline__ __attribute__((always_inline))
template <typename T, int maxn>
class SuperBinaryIndexedTree {
public:
    fastcall IL void init(const int &n) {
        this->n = n;
        t1.init(n);
        t2.init(n);
        return;
    }
    fastcall IL void add(const int &p, const T &x) {
        t1.add(p, x);
        t1.add(p + 1, -x);
        t2.add(p, (p - 1) * x);
        t2.add(p + 1, -p * x);
        return;
    }
    fastcall IL void add(const int &l, const int &r, const T &x) {
        t1.add(l, x);
        t1.add(r + 1, -x);
        t2.add(l, (l - 1) * x);
        t2.add(r + 1, -r * x);
        return;
    }
    fastcall IL T query(const int &p) const {
        return (p * t1.sum(p) - (p - 1) * t1.sum(p - 1)) - (t2.sum(p) - t2.sum(p - 1));
    }
    fastcall IL T query(const int &l, const int &r) const {
        return (r * t1.sum(r) - (l - 1) * t1.sum(l - 1)) - (t2.sum(r) - t2.sum(l - 1));
    }

private:
    class BinaryIndexedTree {
    public:
        fastcall IL void init(const int &n) {
            this->n = n;
            memset(A, 0, sizeof(A));
            memset(C, 0, sizeof(C));
            return;
        }
        fastcall IL void add(int p, const T &x) {
            while (p <= n) {
                C[p] += x;
                p += lowbit(p);
            }
            return;
        }
        fastcall IL T sum(int num) const {
            T ret = 0;
            while (num) {
                ret += C[num];
                num -= lowbit(num);
            }
            return ret;
        }

    private:
        T A[maxn], C[maxn];
        int n;
        fastcall IL int lowbit(const int &num) const { return num & (-num); }
    };
    BinaryIndexedTree t1, t2;
    int n;
};
}  // namespace superbinaryindexedtree
using namespace superbinaryindexedtree;
