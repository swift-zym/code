#pragma once

#include <cmath>
#include <cstring>
namespace lowestcommonancestor {
using namespace std;
#define fastcall __attribute__((optimize("-O3")))
#define IL __inline__ __attribute__((always_inline))
template <typename T, int maxn>
class LowestCommonAncestor {
public:
    LowestCommonAncestor(void) {
        for (int i = 1; i < maxn; i++) lg[i] = lg[i - 1] + ((1 << lg[i - 1]) == i);
        clear();
        return;
    }
    fastcall IL void AddEdge(const int &u, const int &v, const T &val = 1) {
        add(u, v, val);
        add(v, u, val);
        return;
    }
    fastcall IL void clear(void) {
        cnt = n = r = 0;
        memset(depth, 0, sizeof(depth));
        memset(head, 0, sizeof(head));
        memset(anc, 0, sizeof(anc));
        memset(G, 0, sizeof(G));
        memset(d, 0, sizeof(d));
        return;
    }
    fastcall IL void preprocess(const int &root, const int &n) {
        this->n = n;
        r = root;
        depth[0] = d[0] = 0;
        build(r);
        for (int j = 1; j <= (int)log2(maxn); j++) {
            for (int i = 1; i <= n; i++) {
                if (j > depth[i])
                    continue;
                anc[i][j] = anc[anc[i][j - 1]][j - 1];
            }
        }
        return;
    }
    fastcall IL int LCA(int x, int y) {
        if (depth[x] < depth[y])
            x ^= y ^= x ^= y;
        while (depth[x] > depth[y]) x = anc[x][lg[depth[x] - depth[y]] - 1];
        if (x == y)
            return x;
        for (int i = lg[depth[x]] - 1; i >= 0; i--)
            if (anc[x][i] != anc[y][i])
                x = anc[x][i], y = anc[y][i];
        return anc[x][0];
    }
    fastcall IL T dist(const int &u, const int &v) { return d[u] + d[v] - (d[LCA(u, v)] << 1); }

private:
    int n, r, maxlg;
    int anc[maxn][(int)(log2(maxn) + 1)];
    int depth[maxn], lg[maxn];
    T d[maxn];
    struct node {
        int to, nxt;
        T val;
    };
    int cnt;
    node G[maxn << 1];
    int head[maxn];
    fastcall IL void add(const int &u, const int &v, const T &val) {
        G[++cnt].to = v;
        G[cnt].nxt = head[u];
        G[cnt].val = val;
        head[u] = cnt;
        return;
    }
    fastcall void build(const int &u, const int &fa = 0) {
        anc[u][0] = fa;
        depth[u] = depth[fa] + 1;
        for (int i = head[u]; i; i = G[i].nxt)
            if (G[i].to != fa) {
                d[G[i].to] = d[u] + G[i].val;
                build(G[i].to, u);
            }
        return;
    }
};
template <typename T, int maxn>
using LCA = LowestCommonAncestor<T, maxn>;
}  // namespace lowestcommonancestor
using namespace lowestcommonancestor;
