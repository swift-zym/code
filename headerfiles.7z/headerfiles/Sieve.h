#pragma once

#include <algorithm>
#include <vector>
namespace sieve {
using namespace std;
#define fastcall __attribute__((optimize("-O3")))
#define IL __inline__ __attribute__((always_inline))
vector<bool> tisprime;
vector<int> tprimes, tphi, tmu;
fastcall IL void Sieve(const int &n, vector<bool> &isprime = tisprime, vector<int> &primes = tprimes,
                       vector<int> &phi = tphi, vector<int> &mu = tmu) {
    isprime.clear();
    isprime.resize(n + 1);
    fill(isprime.begin(), isprime.end(), true);
    primes.clear();
    phi.clear();
    phi.resize(n + 1);
    phi[1] = 1;
    mu.clear();
    mu.resize(n + 1);
    mu[1] = 1;
    for (int i = 2; i <= n; i++) {
        if (isprime[i]) {
            primes.push_back(i);
            phi[i] = i - 1;
            mu[i] = -1;
        }
        for (int j = 0; j < primes.size() && (long long)i * primes[j] <= n; j++) {
            isprime[i * primes[j]] = false;
            if (i % primes[j]) {
                phi[i * primes[j]] = phi[i] * (primes[j] - 1);
                mu[i * primes[j]] = -mu[i];
            } else {
                phi[i * primes[j]] = phi[i] * primes[j];
                mu[i * primes[j]] = 0;
                break;
            }
        }
    }
    return;
}
}  // namespace sieve
using namespace sieve;
