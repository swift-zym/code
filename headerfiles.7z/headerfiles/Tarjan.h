#pragma once

#include <cstring>
#include <stack>
namespace tarjan {
using namespace std;
#define fastcall __attribute__((optimize("-O3")))
#define IL __inline__ __attribute__((always_inline))
template <int maxn>
class Tarjan {
public:
    Tarjan(void) { init(); }
    fastcall IL void init(void) {
        memset(G, 0, sizeof(G));
        memset(head, 0, sizeof(head));
        cnt = 0;
        return;
    }
    fastcall IL void AddEdge(const int &u, const int &v) {
        G[++cnt].to = v;
        G[cnt].nxt = head[u];
        head[u] = cnt;
        return;
    }
    int sccno[maxn], sccnum[maxn], scc_cnt;
    fastcall IL void tarjan(int n) {
        dfs_clock = scc_cnt = 0;
        memset(sccno, 0, sizeof(sccno));
        memset(pre, 0, sizeof(pre));
        for (int i = 1; i <= n; i++)
            if (!pre[i])
                dfs(i);
        return;
    }
    struct edge {
        int to, nxt;
    };
    edge G[maxn];
    int head[maxn], cnt;

private:
    stack<int> s;
    int dfs_clock;
    int pre[maxn], lowlink[maxn];
    fastcall void dfs(int u) {
        pre[u] = lowlink[u] = ++dfs_clock;
        s.push(u);
        for (int i = head[u]; i; i = G[i].nxt) {
            int v = G[i].to;
            if (!pre[v]) {
                dfs(v);
                lowlink[u] = min(lowlink[u], lowlink[v]);
            } else if (!sccno[v])
                lowlink[u] = min(lowlink[u], pre[v]);
        }
        if (lowlink[u] == pre[u]) {
            scc_cnt++;
            int v;
            do {
                v = s.top();
                s.pop();
                sccnum[scc_cnt]++;
                sccno[v] = scc_cnt;
            } while (u != v);
        }
        return;
    }
};
}  // namespace tarjan
using namespace tarjan;
