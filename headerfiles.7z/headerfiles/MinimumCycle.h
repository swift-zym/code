#pragma once

#include <cstring>
#include <vector>
namespace minimumcycle {
using namespace std;
#define fastcall __attribute__((optimize("-O3")))
#define IL __inline__ __attribute__((always_inline))
template <typename T, int maxn>
class MinimumCycle {
public:
    MinimumCycle(void) {
        memset(val, 0x3f, sizeof(val));
        memset(d, 0, sizeof(d));
        n = 0;
    }
    fastcall IL void init(const int &n) {
        memset(val, 0x3f, sizeof(val));
        memset(d, 0, sizeof(d));
        this->n = n;
        return;
    }
    fastcall IL void AddEdge(const int &u, const int &v, const int &val) {
        if (this->val[u][v] > val)
            this->val[u][v] = this->val[v][u] = val;
        return;
    }
    fastcall IL int solve(vector<int> &path = tmp) {
        static T pre[maxn][maxn];
        memset(pre, 0, sizeof(pre));
        path.clear();
        for (int i = 1; i <= n; i++)
            for (int j = 1; j <= n; j++) pre[i][j] = i;
        for (int i = 1; i <= n; i++)
            for (int j = i; j <= n; j++) d[i][j] = d[j][i] = val[i][j];
        int ret = val[0][0], u;
        for (int k = 1; k <= n; k++) {
            for (int i = 1; i < k; i++)
                for (int j = i + 1; j < k; j++)
                    if (d[i][j] != val[0][0] && val[i][k] != val[0][0] && val[k][j] != val[0][0] &&
                        d[i][j] + val[i][k] + val[k][j] < ret) {
                        ret = d[i][j] + val[i][k] + val[k][j];
                        u = j;
                        path.clear();
                        while (u != i) {
                            path.push_back(u);
                            u = pre[i][u];
                        }
                        path.push_back(i);
                        path.push_back(k);
                    }
            for (int i = 1; i <= n; i++)
                if (d[i][k] != val[0][0])
                    for (int j = 1; j <= n; j++)
                        if (d[k][j] != val[0][0] && d[i][j] > d[i][k] + d[k][j]) {
                            d[i][j] = d[i][k] + d[k][j];
                            pre[i][j] = pre[k][j];
                        }
        }
        return ret;
    }

private:
    T d[maxn][maxn], val[maxn][maxn];
    int n;
    static vector<int> tmp;
};
}  // namespace minimumcycle
using namespace minimumcycle;
