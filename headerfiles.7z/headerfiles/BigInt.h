#pragma once

#include <algorithm>
#include <iostream>
#include <cassert>
#include <cstring>
#include <climits>
#include <string>
#include <vector>
namespace bigint {
using namespace std;
#define fastcall __attribute__((optimize("-O3")))
#define IL __inline__ __attribute__((always_inline))
class BigInt {
public:
    BigInt(long long num = 0) : f(true) { *this = num; }
    BigInt(const string& str) : f(true) { *this = str; }
    fastcall IL friend istream& operator>>(istream& in, BigInt& x) {
        string str;
        if (!(in >> str))
            return in;
        if (str[0] == '-')
            x.f = false, str = str.substr(1);
        x = str;
        return in;
    }
    fastcall IL friend ostream& operator<<(ostream& out, const BigInt& x) {
        if (!x.sign())
            cout << '-';
        out << x.s.back();
        for (int i = x.s.size() - 2; i >= 0; i--) {
            char buf[20];
            sprintf(buf, "%01d", x.s[i]);
            for (int j = 0; j < strlen(buf); j++) out << buf[j];
        }
        return out;
    }
    fastcall IL BigInt operator=(long long num) {
        if (num < 0)
            f = false, num = -num;
        s.clear();
        do {
            s.push_back(num % base);
            num /= base;
        } while (num > 0);
        return *this;
    }
    fastcall IL BigInt operator=(string str) {
        s.clear();
        if (str[0] == '-')
            str = str.substr(1), f = false;
        int x, len = (str.length() - 1) / size + 1;
        for (int i = 0; i < len; i++) {
            int end = str.length() - i * size;
            int start = max(0, end - size);
            sscanf(str.substr(start, end - start).c_str(), "%d", &x);
            s.push_back(x);
        }
        return *this;
    }
    fastcall IL void reset(void) {
        f = true;
        s.clear();
        return;
    }
    fastcall IL bool sign(void) const { return f; }
    fastcall IL int length(void) const { return s.size(); }
    fastcall IL int operator[](const int& p) const { return s[p]; }
    fastcall IL bool operator<(const BigInt& rhs) const { return cmp(*this, rhs) == -1; }
    fastcall IL bool operator>(const BigInt& rhs) const { return cmp(*this, rhs) == 1; }
    fastcall IL bool operator<=(const BigInt& rhs) const { return cmp(*this, rhs) != 1; }
    fastcall IL bool operator>=(const BigInt& rhs) const { return cmp(*this, rhs) != -1; }
    fastcall IL bool operator==(const BigInt& rhs) const { return !cmp(*this, rhs); }
    fastcall IL bool operator!=(const BigInt& rhs) const { return cmp(*this, rhs); }
    static fastcall IL BigInt abs(BigInt num) {
        num.f = true;
        return num;
    }
    fastcall IL explicit operator bool() const { return *this != 0; }
    fastcall IL explicit operator long long() const {
        long long ret = 0;
        for (int i = length() - 1; i >= 0; i--) ret = ((ret << 3) + (ret << 1) + s[i]);
        if (!sign())
            ret *= -1;
        return ret;
    }
    fastcall IL BigInt operator-() const {
        BigInt ret = *this;
        ret.f = !f;
        return ret;
    }
    fastcall IL BigInt operator+(const BigInt& num) const {
        int s = ((!*this) << 1) + (!num);
        switch (s) {
            case 0:
                break;
            case 1:
                return *this;
                break;
            case 2:
                return num;
                break;
            case 3:
                return 0;
                break;
            default:
                break;
        }
        BigInt ret;
        ret.reset();
        if (sign() != num.sign()) {
            if (*this == -num)
                return 0;
            BigInt tmp1 = abs(*this), tmp2 = abs(num);
            if (tmp1 > tmp2) {
                ret = tmp1 - tmp2;
                ret.f = sign();
            } else {
                ret = tmp2 - tmp1;
                ret.f = num.sign();
            }
            return ret;
        }
        if (sign() == num.sign())
            ret.f = sign();
        int len = max(length(), num.length()), x;
        for (int i = 0; i < len; i++) {
            x = 0;
            if (i < length())
                x += this->s[i];
            if (i < num.length())
                x += num[i];
            ret.s.push_back(x);
        }
        ret.maintain();
        return ret;
    }
    fastcall BigInt operator-(const BigInt& num) const {
        if (*this == num)
            return 0;
        int s = ((!*this) << 1) + (!num);
        switch (s) {
            case 0:
                break;
            case 1:
                return *this;
                break;
            case 2:
                return -num;
                break;
            case 3:
                return 0;
                break;
            default:
                break;
        }
        BigInt ret;
        ret.reset();
        int stat = (sign() << 1) + num.sign();
        BigInt tmp1, tmp2;
        tmp1 = abs(*this), tmp2 = abs(num);
        switch (stat) {
            case 0:
                return tmp2 - tmp1;
                break;
            case 1:
                return -(tmp1 + tmp2);
                break;
            case 2:
                return tmp1 + tmp2;
                break;
            case 3:
                if (tmp1 < tmp2)
                    return -(num - *this);
                break;
            default:
                break;
        }
        for (int i = 0; i < length(); i++) {
            ret.s.push_back(this->s[i]);
            if (i < num.length())
                ret.s[i] -= num[i];
        }
        for (int i = 0; i < length() - 1; i++)
            if (ret[i] < 0)
                ret.s[i] += base, ret.s[i + 1]--;
        ret.maintain();
        return ret;
    }
    fastcall IL BigInt operator*(const BigInt& num) const {
        if (!*this || !num)
            return 0;
        int lim = 1;
        while (lim < (length() << 1)) lim <<= 1;
        while (lim < (num.length() << 1)) lim <<= 1;
        vector<int> r;
        getvec(r, lim);
        vector<int> a = s, b = num.s;
        a.resize(lim);
        b.resize(lim);
        NTT(a, lim, r);
        NTT(b, lim, r);
        vector<int> c;
        c.clear();
        for (int i = 0; i < lim; i++) c.push_back(((long long)a[i] * b[i]) % mod);
        NTT(c, lim, r, true);
        BigInt ret;
        ret.reset();
        ret.s.push_back(c[lim - 1]);
        for (int i = 0; i < lim - 1; i++) ret.s.push_back(c[i]);
        ret.f = (sign() + num.sign()) ^ 1;
        ret.maintain();
        return ret;
    }
    fastcall IL BigInt operator/(const BigInt& num) const {
        if (num == 0) {
            assert(false);
            return -1;
        }
        if (*this < num)
            return 0;
        BigInt inv = 1, t;
        bool flag = (sign() + num.sign()) ^ 1;
        BigInt numm = abs(num);
        if (abs(*this) <= (BigInt)LLONG_MAX && numm <= (BigInt)LLONG_MAX)
            return (long long)(*this) / (long long)(num);
        int fac = numm.length(), lim = numm.length() << 1;
        const static int times = 20;
        for (int i = 1; i <= times; i++) {
            t = 0;
            t.s.resize(fac + 1);
            t.s[fac] = 2;
            inv = inv * (t - numm * inv);
            fac *= 2;
            if (inv.length() > lim) {
                fac -= (inv.length() - lim);
                inv.cut(lim);
            }
        }
        BigInt ret = abs(*this) * inv;
        ret.cut(ret.length() - fac);
        ret.f = flag;
        return ret;
    }
    fastcall IL BigInt operator%(const BigInt& num) const { return *this - (*this / num) * num; }

private:
    const static int base = 10, size = 1;
    vector<int> s;
    bool f;
    fastcall IL void cut(const int& len) {
        int m = length() - len;
        for (int i = 0; i < len; i++) s[i] = s[i + m];
        for (int i = length() - 1; i >= len; i--) s.pop_back();
        return;
    }
    fastcall IL void maintain(void) {
        s.push_back(0);
        for (int i = 0; i < s.size(); i++) s[i + 1] += s[i] / base, s[i] %= base;
        while (!s[s.size() - 1]) s.pop_back();
        while (s[s.size() - 1]) {
            s.push_back(s[s.size() - 1] / base);
            s[s.size() - 2] %= base;
        }
        s.pop_back();
        return;
    }
    const static int mod = 998244353;
    static fastcall IL int Power(int b, int e, const int& mod) {
        int ret = 1;
        while (e) {
            if (e & 1)
                ret = ((long long)ret * b) % mod;
            e >>= 1;
            b = ((long long)b * b) % mod;
        }
        return ret;
    }
    static fastcall IL void getvec(vector<int>& r, const int& n) {
        r.clear();
        r.push_back(0);
        for (int i = 1; i < n; i++) r.push_back((r[i >> 1] >> 1) | ((i & 1) ? n >> 1 : 0));
        return;
    }
    static fastcall IL void NTT(vector<int>& v, const int& lim, const vector<int>& r,
                                const bool& opt = false) {
        for (int i = 0; i < lim; i++)
            if (r[i] < i)
                v[i] ^= v[r[i]] ^= v[i] ^= v[r[i]];
        int k, g, tmpg, t;
        for (int m = 2; m <= lim; m <<= 1) {
            k = m >> 1;
            g = Power(3, (mod - 1) / m, mod);
            for (int i = 0; i < lim; i += m) {
                tmpg = 1;
                for (int j = 0; j < k; j++, tmpg = ((long long)tmpg * g) % mod) {
                    t = ((long long)v[i + j + k] * tmpg) % mod;
                    v[i + j + k] = (v[i + j] - t + mod) % mod;
                    v[i + j] = (v[i + j] + t) % mod;
                }
            }
        }
        if (opt) {
            reverse(v.begin(), v.end());
            int inv = Power(lim, mod - 2, mod);
            for (int i = 0; i < lim; i++) v[i] = ((long long)v[i] * inv) % mod;
        }
        return;
    }
    static fastcall IL int cmp(const BigInt& a, const BigInt& b) {
        if (a.sign() != b.sign())
            return a.sign() ? 1 : -1;
        if (a.length() != b.length())
            return a.length() > b.length() ? 1 : -1;
        for (int i = a.length() - 1; i >= 0; i--)
            if (a[i] != b[i])
                return a[i] > b[i] ? 1 : -1;
        return 0;
    }
};
}  // namespace bigint
using namespace bigint;
