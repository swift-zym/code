#pragma once

#include <cstring>
#include <vector>
#include <deque>
namespace systemofdifferenceconstraints {
using namespace std;
#define fastcall __attribute__((optimize("-O3")))
#define IL __inline__ __attribute__((always_inline))
template <typename T, int maxn, int R = 200, int dist = 10>
class SystemofDifferenceConstraints {
public:
    SystemofDifferenceConstraints(void) { init(); }
    fastcall IL void init(void) {
        s1.init();
        s2.init();
        return;
    }
    // ans[a] - ans[b] <= val
    fastcall IL void AddClause(const int &a, const int &b, const T &val) {
        s1.AddEdge(b, a, val);
        s2.AddEdge(b, a, val);
    }
    fastcall IL bool solve(const int &n, vector<int> &ans = tmp) {
        ans.clear();
        if (s1.negativecycle(n))
            return false;
        for (int i = 1; i <= n; i++) s2.AddEdge(0, i, 0);
        s2.bellmanford(0);
        for (int i = 1; i <= n; i++) ans.push_back(s2.d[i]);
        return true;
    }

private:
    static vector<int> tmp;
    class NegativeCycle {
    public:
        NegativeCycle(void) { init(); }
        fastcall IL void init(void) {
            memset(G, 0, sizeof(G));
            memset(head, 0, sizeof(head));
            cnt = 0;
            return;
        }
        fastcall IL void AddEdge(const int &u, const int &v, const T &val) {
            G[++cnt].to = v;
            G[cnt].nxt = head[u];
            G[cnt].val = val;
            head[u] = cnt;
            return;
        }
        fastcall IL bool negativecycle(const int &n) {
            f = false;
            memset(inq, false, sizeof(inq));
            memset(d, 0, sizeof(d));
            for (int i = 1; i <= n; i++) {
                dfs(i);
                if (f)
                    break;
            }
            return f;
        }
        struct edge {
            int to, nxt;
            T val;
        };
        edge G[maxn];
        int head[maxn], cnt;

    private:
        T d[maxn];
        bool inq[maxn], f;
        fastcall void dfs(const int &u) {
            if (f)
                return;
            inq[u] = true;
            for (int i = head[u]; i; i = G[i].nxt) {
                if (f)
                    return;
                if (d[G[i].to] > d[u] + G[i].val) {
                    if (inq[G[i].to]) {
                        f = true;
                        return;
                    }
                    d[G[i].to] = d[u] + G[i].val;
                    dfs(G[i].to);
                }
            }
            inq[u] = false;
            return;
        }
    };
    NegativeCycle s1;
    class BellmanFord {
    public:
        BellmanFord(void) { init(); }
        fastcall IL void init(void) {
            memset(G, 0, sizeof(G));
            memset(head, 0, sizeof(head));
            cnt = 0;
            return;
        }
        fastcall IL void AddEdge(const int &u, const int &v, const T &val) {
            G[++cnt].to = v;
            G[cnt].nxt = head[u];
            G[cnt].val = val;
            head[u] = cnt;
            return;
        }
        T d[maxn];
        int p[maxn];
        fastcall IL void bellmanford(const int &s = 1) {
            deque<int> Q;
            memset(d, 0x3f, sizeof(d));
            memset(inq, false, sizeof(inq));
            d[s] = 0, inq[s] = true;
            memset(c, 0, sizeof(c));
            memset(p, 0, sizeof(p));
            Q.push_front(s);
            while (!Q.empty()) {
                int u = Q.front();
                Q.pop_front();
                inq[u] = false;
                for (int i = head[u]; i; i = G[i].nxt)
                    if (d[G[i].to] > d[u] + G[i].val) {
                        d[G[i].to] = d[u] + G[i].val;
                        p[G[i].to] = i;
                        if (!inq[G[i].to]) {
                            inq[G[i].to] = true;
                            if (c[G[i].to] && c[G[i].to] < R) {
                                Q.push_front(G[i].to);
                                c[G[i].to]++;
                            } else {
                                if (!Q.size())
                                    Q.push_back(G[i].to);
                                else if (d[*(Q.begin())] >= d[G[i].to] - dist)
                                    Q.push_front(G[i].to);
                                else
                                    Q.push_back(G[i].to);
                                if (!c[G[i].to])
                                    c[G[i].to] = 1;
                            }
                        }
                    }
            }
            return;
        }
        struct edge {
            int to, nxt;
            T val;
        };
        edge G[maxn];
        int head[maxn], cnt;

    private:
        bool inq[maxn];
        int c[maxn];
    };
    BellmanFord s2;
};
}  // namespace systemofdifferenceconstraints
using namespace systemofdifferenceconstraints;
