#pragma once

#include <cstring>
#include <vector>
namespace trie {
using namespace std;
#define fastcall __attribute__((optimize("-O3")))
#define IL __inline__ __attribute__((always_inline))
template <int maxn, int sigmasize>
class Trie {
public:
    Trie() { clear(); }
    fastcall IL void clear(void) {
        cnt = 1;
        memset(ch[0], 0, sizeof(ch[0]));
        memset(val, 0, sizeof(val));
        return;
    }
    fastcall IL bool insert(const vector<int> &v, const int &num = 1) {
        int len = v.size(), u = 0;
        bool f = false;
        for (int i = 0; i < len; i++) {
            if (!ch[u][v[i]]) {
                memset(ch[cnt], 0, sizeof(ch[cnt]));
                val[cnt] = 0;
                ch[u][v[i]] = cnt++;
            } else if (i + 1 == len)
                f = true;
            u = ch[u][v[i]];
            if (val[u])
                f = true;
        }
        val[u] = num;
        return f;
    }
    fastcall IL bool find(const vector<int> &v) const {
        int len = v.size(), u = 0;
        for (int i = 0; i < len; i++) {
            if (!ch[u][v[i]])
                return false;
            u = ch[u][v[i]];
        }
        return true;
    }

private:
    int ch[maxn][sigmasize];
    int val[maxn], cnt;
};
}  // namespace trie
using namespace trie;
