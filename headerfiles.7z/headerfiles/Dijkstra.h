#pragma once

#include <cstring>
#include <queue>
namespace dijkstra {
using namespace std;
#define fastcall __attribute__((optimize("-O3")))
#define IL __inline__ __attribute__((always_inline))
template <typename T, int maxn>
class Dijkstra {
public:
    Dijkstra(void) { init(); }
    fastcall IL void init(void) {
        memset(G, 0, sizeof(G));
        memset(head, 0, sizeof(head));
        cnt = 0;
        return;
    }
    fastcall IL void AddEdge(const int &u, const int &v, const T &val) {
        G[++cnt].to = v;
        G[cnt].nxt = head[u];
        G[cnt].val = val;
        head[u] = cnt;
        return;
    }
    T d[maxn];
    int p[maxn];
    fastcall IL void dijkstra(const int &s = 1) {
        priority_queue<Node> Q;
        memset(d, 0x3f, sizeof(d));
        d[s] = 0;
        memset(done, false, sizeof(done));
        memset(p, 0, sizeof(p));
        Q.push((Node){ 0, s });
        while (!Q.empty()) {
            int u = Q.top().u;
            Q.pop();
            if (done[u])
                continue;
            done[u] = true;
            for (int i = head[u]; i; i = G[i].nxt) {
                if (d[G[i].to] > d[u] + G[i].val) {
                    d[G[i].to] = d[u] + G[i].val;
                    p[G[i].to] = i;
                    Q.push((Node){ d[G[i].to], G[i].to });
                }
            }
        }
        return;
    }
    struct edge {
        int to, nxt;
        T val;
    };
    edge G[maxn];
    int head[maxn], cnt;

private:
    bool done[maxn];
    struct Node {
        T d;
        int u;
        bool operator<(const Node &x) const { return d > x.d; }
    };
};
}  // namespace dijkstra
using namespace dijkstra;
