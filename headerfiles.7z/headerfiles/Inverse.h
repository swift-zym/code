#pragma once

namespace inverse {
using namespace std;
#define fastcall __attribute__((optimize("-O3")))
#define IL __inline__ __attribute__((always_inline))
template <typename T>
fastcall void exgcd(const T &a, const T &b, T &g, T &x, T &y) {
    if (b) {
        exgcd(b, a % b, g, y, x);
        y -= x * (a / b);
        return;
    }
    g = a, x = 1, y = 0;
    return;
}
template <typename T>
fastcall IL T Inverse(const T &a, const T &p) {
    T g, x, y;
    exgcd(a, p, g, x, y);
    x %= p;
    if (x < 0)
        x += p;
    return x;
}
}  // namespace inverse
using namespace inverse;
