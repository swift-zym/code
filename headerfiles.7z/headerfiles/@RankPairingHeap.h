#define MAXN 100000
#define MAXM 1000000
#define Log_Phi_N 29

//点数，边数，桶数量

#ifndef NULL
#define NULL 0
#endif

#include <string.h>
#include <stdlib.h>
#include <stdio.h>

template <class T>
struct RP_Heap {
    struct ListNode;
    struct Node {
        T val;
        int rank;
        Node *l, *r, *fa;
        ListNode* p;
        Node() {}
        Node(T _val, int _rank = 0, Node* _l = 0, Node* _r = 0, Node* _fa = 0)
            : val(_val), rank(_rank), l(_l), r(_r), fa(_fa) {}
    } t[MAXN + 2], *p[MAXN + 2], *min, *bucket[Log_Phi_N + 1];
    int cnt, siz;
    bool has_min;
    struct ListNode {
        Node* ptr;
        ListNode *pre, *nxt;
    };
    struct List  //手写链表
    {
        ListNode* head;
        List() {
            head = new ListNode();
            head->ptr = NULL;
            head->nxt = head;
            head->pre = head;
        }
        inline void insert(Node* _ptr) {
            ListNode* u = new ListNode();
            u->ptr = _ptr;
            u->pre = head;
            u->nxt = head->nxt;
            head->nxt->pre = u;
            head->nxt = u;
            _ptr->p = u;
        }
        inline void remove(ListNode* u) {
            u->pre->nxt = u->nxt;
            u->nxt->pre = u->pre;
            u->ptr->p = NULL;
            delete u;
        }
    } list;
    RP_Heap() {
        for (int i = 0; i < MAXN; i++) p[i] = &t[i];  // p[i]指向t[i]，便于分配空间
        has_min = 0;                                  // has_min让extract-min之后不用把min赋为-inf
        memset(bucket, 0, sizeof(bucket));
    }
    inline Node* new_Node(T v)  //这句话就是分配一个新结点，val为v的意思（
    {
        return (&(*p[cnt++] = Node(v, 0, NULL, NULL, NULL)));
    }
    inline void swap(int& x, int& y) {
        int temp = x;
        x = y;
        y = temp;
    }
    inline int max(int x, int y) { return x > y ? x : y; }
    inline int abs(int x) { return x > 0 ? x : -x; }
    inline void swap(Node*& x, Node*& y) {
        Node* temp = x;
        x = y;
        y = temp;
    }
    //这个swap一定记得加&
    inline Node* link(Node* u, Node* v) {
        if (v->val < u->val)
            swap(u, v);
        v->r = u->l;
        if (v->r)  //记得判断是不是空指针，否则RE，以下类似的省略注释
            v->r->fa = v;
        u->l = v;
        v->fa = u;
        u->rank++;
        return u;
    }
    inline Node* update_min(Node* u)  //更新min，为了写起来舒服，返回值是给的指针
    {
        if (!has_min || u->val < min->val)
            min = u, has_min = 1;
        return u;
    }
    inline Node* insert(T _val) {
        Node* u = new_Node(_val);
        list.insert(update_min(u));  //看出来update_min这么写舒服了qwq
        siz++;
        return u;
    }
    inline T find_min() { return min->val; }
    inline int size() { return siz; }
    inline bool empty() { return siz == 0; }
    inline void extract_min() {
        siz--;
        list.remove(min->p);
        has_min = 0;
        int rk;
        Node *next_node, *u;
        ListNode* first = list.head->nxt;   //第一个原有根位置
        for (u = min->l; u; u = next_node)  //拆分左子树右链
        {
            next_node = u->r;
            u->fa = u->r = NULL;
            rk = u->rank;
            if (bucket[rk])  //和桶里的合并，扔进根链表
                list.insert(update_min(link(u, bucket[rk]))), bucket[rk] = NULL;
            else  //扔进桶
                bucket[rk] = u;
        }
        for (ListNode *i = first, *next_node; i != list.head; i = next_node) {
            u = i->ptr;
            rk = u->rank;
            next_node = i->nxt;
            list.remove(i);
            if (bucket[rk])
                list.insert(update_min(link(u, bucket[rk]))), bucket[rk] = NULL;
            else
                bucket[rk] = u;
        }
        for (int i = 0; i <= Log_Phi_N; i++)  //遍历桶，把桶里的扔进根链表
            if (bucket[i])
                list.insert(update_min(bucket[i])), bucket[i] = NULL;
    }
    inline void decrease_key(Node* u, T key)  //把u的值变成k(所以需要自己保证是减值不是增值)
    {
        u->val = key;
        if (u->fa == NULL)  //是根，更新min直接返回
        {
            update_min(u);
            return;
        }
        if (u->l)
            u->rank = u->l->rank + 1;  //更新rank为左儿子rank+1
        else
            u->rank = 0;  //没有左儿子，说明是单点
        if (u->r)
            u->r->fa = u->fa;  //把右儿子接到自己原来的位置
        if (u == u->fa->l)
            u->fa->l = u->r;
        else
            u->fa->r = u->r;
        int temp, lrk, rrk;
        for (Node* v = u->fa; v; v = v->fa) {
            lrk = v->l ? v->l->rank : -1;  //实现的小技巧，没有结点的rank视为-1
            rrk = v->r ? v->r->rank : -1;
            temp = max(lrk, rrk) + (abs(lrk - rrk) <= 1 ? 1 : 0);  //根据rank rule计算新的rank
            if (temp == v->rank)                                   //如果没有改变rank，break掉
                break;
            v->rank = temp;
        }
        u->fa = u->r = NULL;  //最后断开父亲和右儿子是因为前面循环开头要用右儿子，懒得再搞临时变量了
        list.insert(update_min(u));  //插入根链表并更新min
    }
};