#pragma once

namespace excrt {
using namespace std;
#define fastcall __attribute__((optimize("-O3")))
#define IL __inline__ __attribute__((always_inline))
template <typename T, int maxn>
class EXCRT {
public:
    struct equation {
        T a, b;
    };
    equation e[maxn];
    int n, cnt;
    EXCRT(const int &n = 0) {
        init(n);
        return;
    }
    fastcall IL void init(const int &n) {
        cnt = 0;
        this->n = n;
        return;
    }
    fastcall IL void AddEquation(const T &a, const T &b) {
        e[++cnt] = (equation){ a, b };
        return;
    }
    fastcall IL T solve(void) const {
        T A = e[1].a, ans = e[1].b, l, x, o;
        for (int i = 2; i <= n; i++) {
            exgcd(A, e[i].a, o, x, l);
            if ((e[i].b - ans % e[i].a + e[i].a) % o)
                return -1;
            x = multyply(x, (((e[i].b - ans % e[i].a + e[i].a) % e[i].a) / o), e[i].a / o);
            ans += x * A;
            A *= (e[i].a / o);
            ans = (ans % A + A) % A;
        }
        return (ans % A + A) % A;
    }

private:
    fastcall void exgcd(const T &a, const T &b, T &g, T &x, T &y) const {
        if (b) {
            exgcd(b, a % b, g, y, x);
            y -= x * (a / b);
            return;
        }
        g = a, x = 1, y = 0;
        return;
    }
    fastcall IL T multyply(T x, T y, T mod) const {
        x %= mod, y %= mod;
        return ((x * y - (T)(((long double)x * y + 0.5) / mod) * mod) % mod + mod) % mod;
    }
};
}  // namespace excrt
using namespace excrt;
