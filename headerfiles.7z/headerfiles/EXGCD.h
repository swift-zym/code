#pragma once

namespace exgcd {
using namespace std;
#define fastcall __attribute__((optimize("-O3")))
#define IL __inline__ __attribute__((always_inline))
template <typename T>
fastcall void EXGCD(const T &a, const T &b, T &g, T &x, T &y) {
    if (b) {
        EXGCD(b, a % b, g, y, x);
        y -= x * (a / b);
        return;
    }
    g = a, x = 1, y = 0;
    return;
}
// ax + by = c
template <typename T>
fastcall IL bool Equation(const T &a, const T &b, const T &c, T &x, T &y) {
    T g = 0;
    EXGCD(a, b, g, x, y);
    if (c % g)
        return false;
    T t = b / g;
    x = ((x + t) * (c / g)) % t;
    if (x < 0)
        x += t;
    y = (c - a * x) / b;
    return true;
}
}  // namespace exgcd
using namespace exgcd;
