#pragma once

#include <algorithm>
#include <cstring>
namespace kruskal {
using namespace std;
#define fastcall __attribute__((optimize("-O3")))
#define IL __inline__ __attribute__((always_inline))
template <typename T, int maxn>
class Kruskal {
public:
    fastcall IL void init(const int &n) {
        this->n = n;
        cnt = 0;
        return;
    }
    fastcall IL void AddEdge(const int &u, const int &v, const T &val) {
        G[++cnt].from = u;
        G[cnt].to = v;
        G[cnt].val = val;
        return;
    }
    fastcall IL T kruskal(void) {
        memset(used, false, sizeof(used));
        T ans = 0;
        int num = 0;
        sort(G + 1, G + cnt + 1);
        s.init(n);
        for (int i = 1; i <= cnt; i++) {
            if (!s.Find(G[i].from, G[i].to)) {
                used[i] = true;
                ans += G[i].val;
                s.Union(G[i].from, G[i].to);
                if (++num == n - 1)
                    break;
            }
        }
        return ans;
    }
    bool used[maxn];
    struct edge {
        int from, to;
        T val;
        inline const bool operator<(const edge &p) const { return val < p.val; }
    };
    int cnt;
    edge G[maxn];

private:
    int n;
    class UnionFindSet {
    public:
        fastcall IL void init(const int &n) {
            memset(fa, 0, sizeof(fa));
            for (int i = 1; i <= n; i++) fa[i] = i;
            memset(rank, 0, sizeof(rank));
            return;
        }
        fastcall IL void Union(const int &u, const int &v) {
            int x = find(u), y = find(v);
            if (rank[x] < rank[y])
                fa[x] = y;
            else {
                fa[y] = x;
                if (rank[x] == rank[y])
                    rank[x]++;
            }
            return;
        }
        fastcall IL bool Find(const int &u, const int &v) { return this->find(u) == this->find(v); }
        int fa[maxn];

    private:
        fastcall int find(const int &u) { return fa[u] == u ? u : fa[u] = find(fa[u]); }
        int rank[maxn];
    };
    UnionFindSet s;
};
}  // namespace kruskal
using namespace kruskal;
