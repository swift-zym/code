#pragma once

#include <algorithm>
namespace pairingheap {
using namespace std;
#define fastcall __attribute__((optimize("-O3")))
#define IL __inline__ __attribute__((always_inline))
template <typename T>
struct node {
    node(const T &val) : val(val) { son = p = fa = nullptr; }
    node *son, *p, *fa;
    T val;
};
template <typename T>
using PairingHeap = node<T> *;
template <typename T>
fastcall IL node<T> *Union(node<T> *a, node<T> *b) {
    if (a == nullptr)
        return b;
    if (b == nullptr)
        return a;
    if (a->val > b->val)
        swap(a, b);
    a->fa = b->fa = nullptr;
    b->p = a->son;
    if (a->son != nullptr)
        a->son->fa = b;
    a->son = b;
    return a;
}
template <typename T>
fastcall node<T> *Merge(node<T> *p) {
    if (p == nullptr || p->p == nullptr)
        return p;
    p->fa = nullptr;
    node<T> *a = p->p, *b = a->p;
    p->p = a->p = nullptr;
    a->fa = nullptr;
    return Union(Union(p, a), Merge(b));
}
template <typename T>
fastcall IL void insert(PairingHeap<T> &p, const T &val) {
    p = Union(p, new node<T>(val));
    return;
}
template <typename T>
fastcall IL T findmin(const PairingHeap<T> &p) {
    if (p == nullptr)
        return 0;
    return p->val;
}
template <typename T>
fastcall IL void deletemin(PairingHeap<T> &p) {
    p = Merge(p->son);
    return;
}
template <typename T>
fastcall IL PairingHeap<T> merge(PairingHeap<T> a, PairingHeap<T> b) {
    return Union(a, b);
}
template <typename T>
fastcall IL void decreasekey(PairingHeap<T> &p, node<T> *x, const T &val) {
    x->val -= val;
    if (x->fa == nullptr)
        return;
    if (x->fa != nullptr)
        if (x->fa->son == x)
            x->fa->son = x->p;
        else
            x->fa->p = x->p;
    if (x->p != nullptr)
        x->p->fa = x->fa;
    x->p = x->fa = nullptr;
    p = Union(p, x);
    return;
}
}  // namespace pairingheap
using namespace pairingheap;
