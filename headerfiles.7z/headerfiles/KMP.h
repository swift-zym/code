#pragma once

#include <vector>
#include <string>
namespace kmp {
using namespace std;
#define fastcall __attribute__((optimize("-O3")))
#define IL __inline__ __attribute__((always_inline))
vector<int> nxt, tmp;
fastcall IL int KMP(const string &t, const string &p, vector<int> &v = tmp) {
    int n = t.length(), m = p.length();
    nxt.clear();
    nxt.push_back(0);
    nxt.push_back(0);
    int q = 0;
    for (int i = 1; i < m; i++) {
        while (q && p[q] != p[i]) q = nxt[q];
        if (p[q] == p[i])
            q++;
        nxt.push_back(q);
    }
    q = 0;
    v.clear();
    for (int i = 0; i < n; i++) {
        while (q && p[q] != t[i]) q = nxt[q];
        if (t[i] == p[q])
            q++;
        if (q == m)
            v.push_back(i - m + 1), q = 0;
    }
    return v.size();
}
}  // namespace kmp
using namespace kmp;
