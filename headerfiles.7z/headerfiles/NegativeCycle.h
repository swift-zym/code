#pragma once

#include <cstring>
namespace negativecycle {
using namespace std;
#define fastcall __attribute__((optimize("-O3")))
#define IL __inline__ __attribute__((always_inline))
template <typename T, int maxn>
class NegativeCycle {
public:
    NegativeCycle(void) { init(); }
    fastcall IL void init(void) {
        memset(G, 0, sizeof(G));
        memset(head, 0, sizeof(head));
        cnt = 0;
        return;
    }
    fastcall IL void AddEdge(const int &u, const int &v, const T &val) {
        G[++cnt].to = v;
        G[cnt].nxt = head[u];
        G[cnt].val = val;
        head[u] = cnt;
        return;
    }
    fastcall IL bool negativecycle(const int &n) {
        f = false;
        memset(inq, false, sizeof(inq));
        memset(d, 0, sizeof(d));
        for (int i = 1; i <= n; i++) {
            dfs(i);
            if (f)
                break;
        }
        return f;
    }
    struct edge {
        int to, nxt;
        T val;
    };
    edge G[maxn];
    int head[maxn], cnt;

private:
    T d[maxn];
    bool inq[maxn], f;
    fastcall void dfs(const int &u) {
        if (f)
            return;
        inq[u] = true;
        for (int i = head[u]; i; i = G[i].nxt) {
            if (f)
                return;
            if (d[G[i].to] > d[u] + G[i].val) {
                if (inq[G[i].to]) {
                    f = true;
                    return;
                }
                d[G[i].to] = d[u] + G[i].val;
                dfs(G[i].to);
            }
        }
        inq[u] = false;
        return;
    }
};
}  // namespace negativecycle
using namespace negativecycle;
