#pragma once

namespace tonellishanks {
using namespace std;
#define fastcall __attribute__((optimize("-O3")))
#define IL __inline__ __attribute__((always_inline))
template <typename T>
fastcall IL T Power(T b, T e, const T &mod) {
    T ret = 1;
    while (e) {
        if (e & 1)
            ret = (ret * b) % mod;
        e >>= 1;
        b = (b * b) % mod;
    }
    return ret;
}
template <typename T>
fastcall IL bool EulersCriterion(const T &a, const T &p) {
    return Power(a, p >> 1, p) == 1;
}
template <typename T>
fastcall IL T TonelliShanks(const T &n, const T &p) {
    if (!EulersCriterion(n, p))
        return -1;
    T Q = p - 1, S = 0, z = 2;
    while (!(Q & 1)) Q >>= 1, S++;
    while (EulersCriterion(z, p)) z++;
    T M = S, c = Power(z, Q, p), t = pow(n, Q, p), R = pow(n, (Q + 1) >> 1);
    T i, tmp, b;
    while (t > 1) {
        i = 0, tmp = t;
        while (tmp != 1) tmp = (tmp * tmp) % p, i++;
        b = Power(c, Power(2, M - i - 1, p), p);
        M = i, c = (b * b) % p, t = (t * c) % p, R = (R * b) % p;
    }
    return t ? R : 0;
}
}  // namespace tonellishanks
using namespace tonellishanks;
