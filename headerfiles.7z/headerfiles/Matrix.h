#pragma once

#include <cassert>
#include <cstring>
namespace matrix {
using namespace std;
#define fastcall __attribute__((optimize("-O3")))
#define IL __inline__ __attribute__((always_inline))
template <typename T, int maxn>
class Matrix {
public:
    Matrix() { memset(val, 0, sizeof(val)); }
    fastcall IL void init(const int &n, const int &m) {
        this->n = n, this->m = m;
        return;
    }
    fastcall IL T *operator[](const int &p) { return val[p]; }
    fastcall IL int getrow(void) { return n; }
    fastcall IL int getcol(void) { return m; }
    fastcall IL Matrix operator+(const Matrix &a) const {
        assert(this->n == a.n && this->m == a.m);
        Matrix ret;
        ret.init(this->n, this->m);
        for (int i = 1; i <= ret.n; i++)
            for (int j = 1; j <= ret.m; j++) ret.val[i][j] = this->val[i][j] + a.val[i][j];
        return ret;
    }
    fastcall IL Matrix operator-(const Matrix &a) const {
        assert(this->n == a.n && this->m == a.m);
        Matrix ret;
        ret.init(this->n, this->m);
        for (int i = 1; i <= ret.n; i++)
            for (int j = 1; j <= ret.m; j++) ret.val[i][j] = this->val[i][j] - a.val[i][j];
        return ret;
    }
    fastcall IL Matrix operator*(Matrix a) const {
        assert(this->m == a.n);
        int n = this->n, m = a.m, p = this->m;
        Matrix ret;
        ret.init(n, m);
        int m1 = m - m % 8;
        for (int i = 1; i <= n; ++i) {
            for (int k = 1; k <= p; ++k) {
                T *y = a[k];
                T x = this->val[i][k], *z = ret[i];
                for (int j = 8; j <= m1; j += 8) {
                    z[1] += x * y[1], z[2] += x * y[2], z[3] += x * y[3], z[4] += x * y[4], z[5] += x * y[5],
                        z[6] += x * y[6], z[7] += x * y[7], z[8] += x * y[8];
                    z += 8, y += 8;
                }
                y = a[k];
                for (int j = m1 + 1; j <= m; ++j) ret[i][j] += x * y[j];
            }
        }
        return ret;
    }
    fastcall IL Matrix operator+=(const Matrix &a) {
        *this = *this + a;
        return *this;
    }
    fastcall IL Matrix operator-=(const Matrix &a) {
        *this = *this - a;
        return *this;
    }
    fastcall IL Matrix operator*=(const Matrix &a) {
        *this = *this * a;
        return *this;
    }
    fastcall IL Matrix operator^(int e) const {
        Matrix ret, b = (*this);
        assert(b.n == b.m);
        int l = b.n;
        ret.init(l, l);
        for (int i = 1; i <= l; i++) ret[i][i] = 1;
        while (e) {
            if (e & 1)
                ret *= b;
            e >>= 1;
            b *= b;
        }
        return ret;
    }

private:
    T val[maxn][maxn];
    int n, m;
};
}  // namespace matrix
using namespace matrix;
