#pragma once

namespace stein {
using namespace std;
#define fastcall __attribute__((optimize("-O3")))
#define IL __inline__ __attribute__((always_inline))
template <typename T>
fastcall IL T gcd(T a, T b) {
    if (!a)
        return b;
    if (!b)
        return a;
    T s = 0;
    while (!((a | b) & 1)) s++, a >>= 1, b >>= 1;
    while (!(a & 1)) a >>= 1;
    do {
        while (!(b & 1)) b >>= 1;
        if (a > b)
            a ^= b ^= a ^= b;
        b -= a;
    } while (b);
    return a << s;
}
}  // namespace stein
using namespace stein;
