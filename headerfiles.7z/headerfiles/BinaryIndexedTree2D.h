#pragma once

#include <cstring>
namespace binaryindexedtree2D {
using namespace std;
#define fastcall __attribute__((optimize("-O3")))
#define IL __inline__ __attribute__((always_inline))
template <typename T, int maxn>
class BinaryIndexedTree2D {
public:
    fastcall IL void init(const int &n) {
        this->n = n;
        memset(C, 0, sizeof(C));
        return;
    }
    fastcall IL void add(int x, const int &y, const T &val) {
        while (x <= n) {
            int i = y;
            while (i <= n) {
                C[x][i] += val;
                i += lowbit(i);
            }
            x += lowbit(x);
        }
        return;
    }
    fastcall IL T sum(int x, const int &y) const {
        T ret = 0;
        while (x) {
            int i = y;
            while (i) {
                ret += C[x][i];
                i -= lowbit(i);
            }
            x -= lowbit(x);
        }
        return ret;
    }

private:
    T C[maxn][maxn];
    int n;
    fastcall IL int lowbit(const int &num) const { return num & (-num); }
};
template <int maxn>
using BITInt2D = BinaryIndexedTree2D<int, maxn>;
template <int maxn>
using BITLongLong2D = BinaryIndexedTree2D<long long, maxn>;
}  // namespace binaryindexedtree2D
using namespace binaryindexedtree2D;
