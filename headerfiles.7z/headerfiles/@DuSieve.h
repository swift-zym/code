#pragma once

#include <unordered_map>
#include <algorithm>
#include <vector>
#include <cmath>
namespace dusieve {
using namespace std;
#define fastcall __attribute__((optimize("-O3")))
#define IL __inline__ __attribute__((always_inline))
class DuSieve {
public:
    DuSieve(void) { mu.clear(); }
    fastcall IL void init(const long long &n) {
        this->n = n;
        long long t = pow((long double)n, (long double)2.0 / 3.0);
        Sieve(t);
        for (int i = 1; i < mu.size(); i++) mu[i] += mu[i - 1];
        return;
    }
    fastcall long long Smu(const long long &p) {
        if (p < mu.size())
            return mu[p];
        if (M.count(p))
            return M[p];
        long long ret = 1;
        for (long long i = 2, j = (p / (p / i)); i <= p; i = j + 1, j = (p / (p / i)))
            ret -= Smu(p / i) * (j - i + 1);
        return M[p] = ret;
    }
    fastcall IL long long Sphi(const long long &p) {
        long long ret = 0;
        for (long long i = 1, j = (p / (p / i)); i <= p; i = j + 1, j = (p / (p / i)))
            ret += (Smu(j) - Smu(i - 1)) * (p / i) * (p / i);
        return ((ret - 1) >> 1) + 1;
    }

private:
    long long n;
    vector<long long> mu;
    unordered_map<long long, long long> M;
    fastcall IL void Sieve(const long long &n) {
        static vector<bool> isprime;
        static vector<long long> primes;
        isprime.clear();
        isprime.resize(n + 1);
        fill(isprime.begin(), isprime.end(), true);
        primes.clear();
        mu.clear();
        mu.resize(n + 1);
        mu[1] = 1LL;
        for (long long i = 2; i <= n; i++) {
            if (isprime[i]) {
                primes.push_back(i);
                mu[i] = -1LL;
            }
            for (long long j = 0; j < primes.size() && (long long)i * primes[j] <= n; j++) {
                isprime[i * primes[j]] = false;
                if (i % primes[j])
                    mu[i * primes[j]] = 0LL;
                else {
                    mu[i * primes[j]] = -mu[i];
                    break;
                }
            }
        }
        return;
    }
};
}  // namespace dusieve
using namespace dusieve;
